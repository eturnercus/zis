#![windows_subsystem = "windows"]

mod error;
mod java;
mod launcher;
mod minecraft;
mod twitch;
mod utils;

use crate::{
    error::{set_global_error, GLOBAL_ERROR},
    twitch::status,
};
use serde::{Deserialize, Serialize};
use std::path::{Path, PathBuf};
use tauri::{
    menu::{Menu, MenuItem},
    tray::{MouseButton, MouseButtonState, TrayIconBuilder, TrayIconEvent},
    AppHandle, Emitter, Manager,
};

#[cfg(target_os = "windows")]
use std::ffi::OsString;
#[cfg(target_os = "windows")]
use std::os::windows::process::CommandExt;

#[derive(Serialize, Clone)]
struct LaunchEvent {
    status: String,
    progress: u8,
}

#[derive(Serialize, Deserialize, Clone)]
pub struct NewsItem {
    pub title: String,
    pub description: String,
    pub image: String,
    pub link: String,
}

fn get_last_error_value() -> String {
    GLOBAL_ERROR.read().unwrap().clone().unwrap_or_default()
}

fn set_client_error(message: impl Into<String>) -> String {
    let message = message.into();
    set_global_error(message.clone());
    message
}

pub fn emit_launch(app: &AppHandle, status: impl Into<String>, progress: u8) {
    let _ = app.emit(
        "launch-status",
        LaunchEvent {
            status: status.into(),
            progress,
        },
    );
}

fn show_main_window(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.show();
        let _ = window.unminimize();
        let _ = window.set_focus();
    }
}

fn hide_main_window(app: &AppHandle) {
    if let Some(window) = app.get_webview_window("main") {
        let _ = window.hide();
    }
}

#[tauri::command]
fn get_last_error() -> String {
    get_last_error_value()
}

#[tauri::command]
async fn check_launcher_update(app: AppHandle) -> Result<Option<String>, String> {
    let manifest = match utils::fetchmanifest::fetch_manifest(
        "https://download.inflexus.world/new/manifest.json",
    )
    .await
    {
        Some(m) => m,
        None => return Ok(None),
    };

    let current = app.package_info().version.to_string();
    let remote = manifest.launcher_version.trim().to_string();
    if current != remote {
        Ok(Some(remote))
    } else {
        Ok(None)
    }
}

async fn perform_launcher_update(
    app: &AppHandle,
    manifest: &utils::fetchmanifest::Manifest,
) -> Result<(), String> {
    #[cfg(target_os = "windows")]
    let (update_url, expected_sha) = (
        manifest.launcher_windows_url.clone(),
        manifest.launcher_windows_sha256.clone(),
    );
    #[cfg(target_os = "linux")]
    let (update_url, expected_sha) = (
        manifest.launcher_linux_url.clone(),
        manifest.launcher_linux_sha256.clone(),
    );

    if update_url.is_empty() {
        return Err("В manifest отсутствует ссылка на обновление лаунчера".to_string());
    }

    let current_exe = std::env::current_exe()
        .map_err(|e| format!("Не удалось определить путь к лаунчеру: {}", e))?;

    let tmp_dir = std::env::temp_dir();
    let update_path = tmp_dir.join("NoteBuns.update");

    emit_launch(app, "Скачивание обновления...", 10);

    let client = utils::fetchmanifest::build_download_client()?;
    let resp = client
        .get(&update_url)
        .send()
        .await
        .map_err(|e| format!("Ошибка загрузки обновления: {}", e))?;

    if !resp.status().is_success() {
        return Err(format!("Сервер вернул ошибку: {}", resp.status()));
    }

    let bytes = resp
        .bytes()
        .await
        .map_err(|e| format!("Ошибка чтения обновления: {}", e))?;

    tokio::fs::write(&update_path, &bytes)
        .await
        .map_err(|e| format!("Ошибка сохранения обновления: {}", e))?;

    if let Some(sha) = expected_sha {
        if !sha.is_empty() {
            emit_launch(app, "Проверка обновления...", 12);
            let valid = crate::utils::hash::verify_hash(update_path.to_str().unwrap_or(""), &sha)
                .await
                .unwrap_or(false);

            if !valid {
                let _ = tokio::fs::remove_file(&update_path).await;
                return Err("Контрольная сумма обновления лаунчера не совпала".to_string());
            }
        }
    }

    emit_launch(app, "Применение обновления...", 14);

    #[cfg(target_os = "windows")]
    {
        let upd = update_path.to_string_lossy().to_string();
        let exe = current_exe.to_string_lossy().to_string();
        let bat = format!(
            "@echo off\r\ntimeout /t 2 /nobreak >nul\r\nmove /y \"{}\" \"{}\"\r\nstart \"\" \"{}\"\r\n",
            upd, exe, exe
        );
        let bat_path = tmp_dir.join("NoteBuns_update.bat");
        std::fs::write(&bat_path, bat).map_err(|e| format!("Ошибка создания скрипта: {}", e))?;
        tokio::process::Command::new("cmd")
            .args(["/C", bat_path.to_str().unwrap_or("")])
            .spawn()
            .map_err(|e| format!("Ошибка запуска скрипта: {}", e))?;
    }

    #[cfg(target_os = "linux")]
    {
        use std::os::unix::fs::PermissionsExt;
        std::fs::set_permissions(&update_path, std::fs::Permissions::from_mode(0o755))
            .map_err(|e| format!("Ошибка прав: {}", e))?;
        let upd = update_path.to_string_lossy().to_string();
        let exe = current_exe.to_string_lossy().to_string();
        let sh = format!(
            "#!/bin/sh\nsleep 2\nmv -f \"{}\" \"{}\"\nexec \"{}\"\n",
            upd, exe, exe
        );
        let sh_path = tmp_dir.join("NoteBuns_update.sh");
        std::fs::write(&sh_path, &sh).map_err(|e| format!("Ошибка создания скрипта: {}", e))?;
        std::fs::set_permissions(&sh_path, std::fs::Permissions::from_mode(0o755))
            .map_err(|e| format!("Ошибка прав на скрипт: {}", e))?;
        tokio::process::Command::new("sh")
            .arg(sh_path.to_str().unwrap_or(""))
            .spawn()
            .map_err(|e| format!("Ошибка запуска скрипта: {}", e))?;
    }

    app.exit(0);
    Ok(())
}

#[tauri::command]
async fn do_launcher_update(app: AppHandle) -> Result<(), String> {
    let manifest =
        utils::fetchmanifest::fetch_manifest("https://download.inflexus.world/new/manifest.json")
            .await
            .ok_or_else(|| "Не удалось получить manifest.json".to_string())?;
    perform_launcher_update(&app, &manifest).await
}

#[tauri::command]
async fn fetch_news() -> Result<Vec<NewsItem>, String> {
    let client = crate::utils::fetchmanifest::build_client().map_err(|e| e.to_string())?;
    let response = client
        .get("https://download.inflexus.world/new/news.json")
        .send()
        .await
        .map_err(|e| e.to_string())?;
    let news: Vec<NewsItem> = response.json().await.map_err(|e| e.to_string())?;
    Ok(news)
}

fn collect_windows_native_jars(libraries_dir: &Path) -> Result<Vec<PathBuf>, String> {
    let mut result = Vec::new();
    let mut stack = vec![libraries_dir.to_path_buf()];

    while let Some(dir) = stack.pop() {
        let entries = std::fs::read_dir(&dir)
            .map_err(|e| format!("Не удалось прочитать {}: {}", dir.display(), e))?;

        for entry in entries {
            let entry = entry.map_err(|e| format!("Ошибка чтения entry: {}", e))?;
            let path = entry.path();

            if path.is_dir() {
                stack.push(path);
                continue;
            }

            let Some(name) = path.file_name().and_then(|n| n.to_str()) else {
                continue;
            };

            let lower = name.to_ascii_lowercase();
            if lower.ends_with(".jar") && lower.contains("natives-windows") {
                result.push(path);
            }
        }
    }

    result.sort();
    Ok(result)
}

fn extract_windows_natives_from_jar(jar_path: &Path, dest_dir: &Path) -> Result<usize, String> {
    let file = std::fs::File::open(jar_path)
        .map_err(|e| format!("Не удалось открыть {}: {}", jar_path.display(), e))?;
    let mut zip = zip::ZipArchive::new(file)
        .map_err(|e| format!("Не удалось прочитать jar {}: {}", jar_path.display(), e))?;

    let mut extracted = 0usize;

    for i in 0..zip.len() {
        let mut entry = zip
            .by_index(i)
            .map_err(|e| format!("Ошибка чтения entry {} в {}: {}", i, jar_path.display(), e))?;

        if entry.is_dir() {
            continue;
        }

        let name = entry.name().replace('\\', "/");
        let lower = name.to_ascii_lowercase();

        if name.contains("..") {
            continue;
        }

        if !lower.ends_with(".dll") {
            continue;
        }

        let file_name = Path::new(&name)
            .file_name()
            .and_then(|n| n.to_str())
            .ok_or_else(|| format!("Некорректное имя файла в {}", jar_path.display()))?;

        let out_path = dest_dir.join(file_name);

        if let Some(parent) = out_path.parent() {
            std::fs::create_dir_all(parent)
                .map_err(|e| format!("Не удалось создать {}: {}", parent.display(), e))?;
        }

        let mut out = std::fs::File::create(&out_path)
            .map_err(|e| format!("Не удалось создать {}: {}", out_path.display(), e))?;

        std::io::copy(&mut entry, &mut out)
            .map_err(|e| format!("Не удалось распаковать {}: {}", out_path.display(), e))?;

        extracted += 1;
    }

    Ok(extracted)
}

fn prepare_windows_natives_blocking(game_dir: &Path) -> Result<PathBuf, String> {
    let libraries_dir = game_dir.join("libraries");
    if !libraries_dir.exists() {
        return Err(format!(
            "Не найдена папка libraries: {}",
            libraries_dir.display()
        ));
    }

    let natives_dir = game_dir.join("natives");

    if natives_dir.exists() {
        std::fs::remove_dir_all(&natives_dir)
            .map_err(|e| format!("Не удалось очистить {}: {}", natives_dir.display(), e))?;
    }

    std::fs::create_dir_all(&natives_dir)
        .map_err(|e| format!("Не удалось создать {}: {}", natives_dir.display(), e))?;

    let jars = collect_windows_native_jars(&libraries_dir)?;
    if jars.is_empty() {
        return Err("Не найдены jars с natives-windows в libraries".to_string());
    }

    let mut total = 0usize;
    for jar in jars {
        total += extract_windows_natives_from_jar(&jar, &natives_dir)?;
    }

    if total == 0 {
        return Err("Не удалось извлечь ни одной Windows native library".to_string());
    }

    Ok(std::fs::canonicalize(&natives_dir).unwrap_or(natives_dir))
}

fn insert_or_replace_jvm_property(command: &mut Vec<String>, key: &str, value: &str) {
    let prefix = format!("-D{}=", key);
    command.retain(|arg| !arg.starts_with(&prefix));

    let arg = format!("{}{}", prefix, value);
    let pos = command
        .iter()
        .position(|arg| arg == "-cp" || arg == "-classpath")
        .unwrap_or(1);

    if pos <= command.len() {
        command.insert(pos, arg);
    } else {
        command.push(arg);
    }
}

#[tauri::command]
async fn start_game(app: AppHandle) -> Result<(), String> {
    match execute_launch_pipeline(&app).await {
        Ok(_) => Ok(()),
        Err(e) => {
            let e = set_client_error(e);
            let _ = app.emit("launch-error", &e);
            show_main_window(&app);
            Err(e)
        }
    }
}

async fn execute_launch_pipeline(app: &AppHandle) -> Result<(), String> {
    let config = crate::launcher::config::get_config(app.clone());
    let app_version = app.package_info().version.to_string();
    let game_dir = config.get_absolute_game_dir(app);

    emit_launch(app, "Получение манифеста...", 5);

    let manifest_data =
        utils::fetchmanifest::fetch_manifest("https://download.inflexus.world/new/manifest.json")
            .await
            .ok_or_else(|| {
                let err = get_last_error_value();
                if err.is_empty() {
                    set_client_error("Не удалось получить manifest.json")
                } else {
                    set_client_error(err)
                }
            })?;

    let remote_version = manifest_data.launcher_version.trim();
    if app_version.as_str() != remote_version {
        emit_launch(app, "Загрузка обновления лаунчера...", 7);
        if let Err(e) = perform_launcher_update(app, &manifest_data).await {
            eprintln!("Обновление лаунчера не удалось: {}", e);
        } else {
            return Ok(());
        }
    }

    #[cfg(target_os = "windows")]
    let (java_url, java_hash, archive_name) = (
        manifest_data
            .java_windows
            .urls
            .first()
            .cloned()
            .ok_or_else(|| set_client_error("В manifest отсутствует ссылка на Java для Windows"))?,
        manifest_data.java_windows.sha256.clone(),
        "java.zip",
    );

    #[cfg(target_os = "linux")]
    let (java_url, java_hash, archive_name) = (
        manifest_data
            .java_linux
            .urls
            .first()
            .cloned()
            .ok_or_else(|| set_client_error("В manifest отсутствует ссылка на Java для Linux"))?,
        manifest_data.java_linux.sha256.clone(),
        "java.tar.gz",
    );

    let java_archive_path = game_dir.join(archive_name);
    let java_dest_dir = game_dir.join("runtime").join("java");
    let java_dest_str = java_dest_dir
        .to_str()
        .ok_or_else(|| set_client_error("Некорректный путь распаковки Java"))?;

    emit_launch(app, "Проверка Java...", 15);

    if !java::download::check_extracted_java(java_dest_str, &java_hash) {
        emit_launch(app, "Загрузка Java...", 18);
        if !java::download::download_java(
            &java_url,
            java_archive_path
                .to_str()
                .ok_or_else(|| set_client_error("Некорректный путь к архиву Java"))?,
            &java_hash,
        )
        .await
        {
            let err = get_last_error_value();
            return Err(if err.is_empty() {
                set_client_error("Не удалось загрузить Java")
            } else {
                set_client_error(err)
            });
        }

        emit_launch(app, "Распаковка Java...", 30);
        java::download::extract_java(
            java_archive_path
                .to_str()
                .ok_or_else(|| set_client_error("Некорректный путь к архиву Java"))?,
            java_dest_str,
            &java_hash,
        )
        .map_err(|e| set_client_error(format!("Ошибка распаковки Java: {}", e)))?;
    }

    let java_bin = java::download::find_java_bin(&java_dest_dir)
        .ok_or_else(|| set_client_error("Не удалось найти бинарник Java после распаковки"))?;

    emit_launch(app, "Получение списка файлов...", 45);

    let index_url = manifest_data
        .index_urls
        .first()
        .cloned()
        .ok_or_else(|| set_client_error("В manifest отсутствует index_urls[0]"))?;

    let index_manifest = utils::fetchmanifest::fetch_index(&index_url)
        .await
        .map_err(|e| set_client_error(e.to_string()))?;

    emit_launch(app, "Синхронизация файлов...", 55);

    minecraft::sync::sync_and_download_game(&game_dir, &index_manifest, app)
        .await
        .map_err(|e| set_client_error(e.to_string()))?;

    #[cfg(target_os = "windows")]
    let natives_dir = {
        emit_launch(app, "Подготовка natives...", 88);
        let game_dir_clone = game_dir.clone();
        tokio::task::spawn_blocking(move || prepare_windows_natives_blocking(&game_dir_clone))
            .await
            .map_err(|e| set_client_error(format!("Ошибка подготовки natives: {}", e)))??
    };

    emit_launch(app, "Подготовка запуска...", 92);

    let mut command = minecraft::launch::build_launch_command(
        java_bin
            .to_str()
            .ok_or_else(|| set_client_error("Некорректный путь к бинарнику Java"))?,
        &game_dir,
        &config.username,
        None,
        "NoteBuns",
        &app_version,
        config.memory_mb as usize,
        config.width,
        config.height,
    )
    .map_err(|e| set_client_error(format!("Ошибка построения команды: {}", e)))?;

    #[cfg(target_os = "windows")]
    {
        let natives_str = natives_dir
            .to_str()
            .ok_or_else(|| set_client_error("Некорректный путь к natives"))?
            .to_string();

        insert_or_replace_jvm_property(&mut command, "java.library.path", &natives_str);
        insert_or_replace_jvm_property(&mut command, "org.lwjgl.librarypath", &natives_str);
    }

    emit_launch(app, "Запуск Minecraft...", 100);
    hide_main_window(app);

    let mut cmd = tokio::process::Command::new(&command[0]);
    cmd.args(&command[1..]);
    cmd.current_dir(&game_dir);

    #[cfg(target_os = "windows")]
    {
        cmd.creation_flags(0x08000000);

        let mut path_value = OsString::new();
        path_value.push(natives_dir.as_os_str());
        path_value.push(";");
        if let Some(existing) = std::env::var_os("PATH") {
            path_value.push(existing);
        }
        cmd.env("PATH", path_value);
    }

    let output = cmd
        .stdout(std::process::Stdio::piped())
        .stderr(std::process::Stdio::piped())
        .output()
        .await
        .map_err(|e| {
            show_main_window(app);
            set_client_error(format!("Не удалось запустить игру: {}", e))
        })?;

    show_main_window(app);

    if !output.status.success() {
        let stderr = String::from_utf8_lossy(&output.stderr);
        let stdout = String::from_utf8_lossy(&output.stdout);
        eprintln!("=== Minecraft stdout ===\n{}", stdout);
        eprintln!("=== Minecraft stderr ===\n{}", stderr);
        return Err(set_client_error(format!(
            "Игра завершилась с ошибкой (код {:?}):\n{}",
            output.status.code(),
            if stderr.is_empty() { stdout } else { stderr }
        )));
    }

    Ok(())
}

fn build_tray(app: &mut tauri::App) -> tauri::Result<()> {
    let show = MenuItem::with_id(app, "show", "Открыть", true, None::<&str>)?;
    let hide = MenuItem::with_id(app, "hide", "Скрыть", true, None::<&str>)?;
    let quit = MenuItem::with_id(app, "quit", "Выход", true, None::<&str>)?;
    let menu = Menu::with_items(app, &[&show, &hide, &quit])?;
    let icon = app
        .default_window_icon()
        .cloned()
        .expect("Иконка приложения не найдена в tauri.conf.json");

    let _tray = TrayIconBuilder::with_id("main-tray")
        .icon(icon)
        .tooltip("Minecraft Launcher")
        .menu(&menu)
        .on_menu_event(|app, event| match event.id().as_ref() {
            "show" => show_main_window(app),
            "hide" => hide_main_window(app),
            "quit" => app.exit(0),
            _ => {}
        })
        .on_tray_icon_event(|tray, event: TrayIconEvent| {
            if let TrayIconEvent::Click {
                button: MouseButton::Left,
                button_state: MouseButtonState::Up,
                ..
            } = event
            {
                show_main_window(&tray.app_handle());
            }
        })
        .build(app)?;

    Ok(())
}

fn main() {
    #[cfg(target_os = "linux")]
    std::env::set_var("WEBKIT_DISABLE_DMABUF_RENDERER", "1");

    tauri::Builder::default()
        .plugin(tauri_plugin_dialog::init())
        .plugin(tauri_plugin_process::init())
        .plugin(tauri_plugin_single_instance::init(
            |app: &AppHandle, _args: Vec<String>, _cwd: String| {
                show_main_window(app);
            },
        ))
        .plugin(tauri_plugin_opener::init())
        .setup(|app| {
            build_tray(app)?;

            if let Some(window) = app.get_webview_window("main") {
                let app_handle = app.handle().clone();
                window.on_window_event(move |event| {
                    if let tauri::WindowEvent::CloseRequested { api, .. } = event {
                        api.prevent_close();
                        hide_main_window(&app_handle);
                    }
                });
            }

            Ok(())
        })
        .invoke_handler(tauri::generate_handler![
            get_last_error,
            start_game,
            check_launcher_update,
            do_launcher_update,
            fetch_news,
            status::check_broadcast,
            crate::launcher::config::get_config,
            crate::launcher::config::save_config,
        ])
        .run(tauri::generate_context!())
        .expect("error while running tauri application");
}
