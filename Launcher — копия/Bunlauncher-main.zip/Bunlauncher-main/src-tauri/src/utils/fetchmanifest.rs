use crate::error::set_global_error;
use crate::minecraft::sync::IndexManifest;
use reqwest::{
    header::{HeaderMap, HeaderName, HeaderValue},
    Client,
};
use serde::Deserialize;
use std::time::Duration;

pub const LAUNCHER_AUTH_HEADER: &str = "X-Launcher-Auth";
pub const LAUNCHER_AUTH_VALUE: &str = "NoteBuns-Authorized-Request-2026";

pub fn get_launcher_headers() -> HeaderMap {
    let mut headers = HeaderMap::new();
    headers.insert(
        HeaderName::from_static("x-launcher-auth"),
        HeaderValue::from_static(LAUNCHER_AUTH_VALUE),
    );
    headers
}

#[derive(Deserialize, Debug, Clone)]
pub struct JavaManifest {
    pub urls: Vec<String>,
    pub sha256: String,
}

#[derive(Deserialize, Debug, Clone)]
pub struct Manifest {
    pub java_version: String,
    pub java_windows: JavaManifest,
    pub java_linux: JavaManifest,
    pub minecraft_version: String,
    pub index_urls: Vec<String>,
    pub files_base_url: String,
    pub launcher_version: String,
    pub launcher_windows_url: String,
    pub launcher_linux_url: String,
    // новые поля — Option чтобы не сломать старые manifest
    pub launcher_windows_sha256: Option<String>,
    pub launcher_linux_sha256: Option<String>,
}

pub fn build_client() -> Result<Client, String> {
    Client::builder()
        .connect_timeout(Duration::from_secs(20))
        .timeout(Duration::from_secs(60))
        .user_agent("NoteBuns Launcher")
        .default_headers(get_launcher_headers())
        .build()
        .map_err(|e| format!("Не удалось создать HTTP клиент: {}", e))
}

pub fn build_download_client() -> Result<Client, String> {
    Client::builder()
        .connect_timeout(Duration::from_secs(30))
        .timeout(Duration::from_secs(7200))
        .pool_idle_timeout(Duration::from_secs(120))
        .pool_max_idle_per_host(32)
        .tcp_keepalive(Duration::from_secs(30))
        .user_agent("NoteBuns Launcher")
        .default_headers(get_launcher_headers())
        .no_gzip()
        .no_brotli()
        .no_deflate()
        .build()
        .map_err(|e| format!("Не удалось создать download клиент: {}", e))
}

pub async fn fetch_manifest(url: &str) -> Option<Manifest> {
    let client = match build_client() {
        Ok(c) => c,
        Err(e) => {
            set_global_error(e);
            return None;
        }
    };
    let response = match client.get(url).send().await {
        Ok(r) => r,
        Err(e) => {
            set_global_error(format!("Ошибка соединения (manifest): {}", e));
            return None;
        }
    };
    if !response.status().is_success() {
        set_global_error(format!("Сервер вернул ошибку: {}", response.status()));
        return None;
    }
    match response.json::<Manifest>().await {
        Ok(m) => Some(m),
        Err(e) => {
            set_global_error(format!("Ошибка парсинга manifest.json: {}", e));
            None
        }
    }
}

pub async fn fetch_index(url: &str) -> Result<IndexManifest, String> {
    let client = build_client()?;
    let response = client
        .get(url)
        .send()
        .await
        .map_err(|e| format!("Ошибка соединения (index): {}", e))?;
    if !response.status().is_success() {
        return Err(format!("Сервер вернул ошибку: {}", response.status()));
    }
    response
        .json::<IndexManifest>()
        .await
        .map_err(|e| format!("Ошибка парсинга index.json: {}", e))
}
