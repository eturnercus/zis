use sha1::{Digest as Sha1Digest, Sha1};
use sha2::{Digest as Sha256Digest, Sha256};
use std::path::Path;
use tokio::fs::File;
use tokio::io::AsyncReadExt;

pub async fn verify_hash(path: &str, expected_hash: &str) -> std::io::Result<bool> {
    let path = Path::new(path);
    if !path.exists() {
        return Ok(false);
    }

    let expected = expected_hash.trim().to_lowercase();
    let mut file = File::open(path).await?;
    let mut buffer = vec![0u8; 128 * 1024]; // 128 KB buffer

    let hash_string = match expected.len() {
        40 => {
            let mut hasher = Sha1::new();
            loop {
                let n = file.read(&mut buffer).await?;
                if n == 0 {
                    break;
                }
                hasher.update(&buffer[..n]);
            }
            hex::encode(hasher.finalize())
        }
        64 => {
            let mut hasher = Sha256::new();
            loop {
                let n = file.read(&mut buffer).await?;
                if n == 0 {
                    break;
                }
                hasher.update(&buffer[..n]);
            }
            hex::encode(hasher.finalize())
        }
        _ => return Ok(false), // Неизвестный алгоритм
    };

    Ok(hash_string == expected)
}
