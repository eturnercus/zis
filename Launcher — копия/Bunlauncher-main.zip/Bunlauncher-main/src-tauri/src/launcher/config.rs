use serde::{Deserialize, Serialize};
use std::fs;
use std::path::PathBuf;
use tauri::{AppHandle, Manager};

#[derive(Serialize, Deserialize, Debug, Clone)]
pub struct LauncherConfig {
    pub username: String,
    pub memory_mb: u32,
    pub width: u32,
    pub height: u32,
    pub game_dir: Option<String>,
}

impl Default for LauncherConfig {
    fn default() -> Self {
        Self {
            username: String::new(),
            memory_mb: 5120,
            width: 1280,
            height: 720,
            game_dir: None,
        }
    }
}

impl LauncherConfig {
    pub fn get_absolute_game_dir(&self, app: &AppHandle) -> PathBuf {
        if let Some(ref path) = self.game_dir {
            if !path.trim().is_empty() {
                return PathBuf::from(path);
            }
        }

        app.path()
            .home_dir()
            .unwrap_or_else(|_| PathBuf::from("."))
            .join(".NoteBuns")
    }

    pub fn normalize(&mut self) {
        self.memory_mb = self.memory_mb.clamp(5120, 12288);
        self.width = self.width.clamp(800, 1920);
        self.height = self.height.clamp(600, 1080);

        self.username = self
            .username
            .chars()
            .filter(|c| c.is_ascii_alphanumeric() || *c == '_')
            .collect();

        if self.username.len() > 16 {
            self.username.truncate(16);
        }

        while self.username.len() < 3 {
            self.username.push('a');
        }
    }
}

fn get_config_path(app: &AppHandle) -> Result<PathBuf, String> {
    let mut path = app.path().app_config_dir().map_err(|e| e.to_string())?;
    fs::create_dir_all(&path).map_err(|e| e.to_string())?;
    path.push("config.json");
    Ok(path)
}

#[tauri::command]
pub fn get_config(app: AppHandle) -> LauncherConfig {
    let mut config = match get_config_path(&app) {
        Ok(path) if path.exists() => fs::read_to_string(&path)
            .ok()
            .and_then(|data| serde_json::from_str::<LauncherConfig>(&data).ok())
            .unwrap_or_default(),
        _ => LauncherConfig::default(),
    };

    config.normalize();
    config
}

#[tauri::command]
pub fn save_config(app: AppHandle, mut config: LauncherConfig) -> Result<(), String> {
    config.normalize();
    let path = get_config_path(&app)?;
    let json_data = serde_json::to_string_pretty(&config).map_err(|e| e.to_string())?;
    fs::write(path, json_data).map_err(|e| e.to_string())?;
    Ok(())
}
