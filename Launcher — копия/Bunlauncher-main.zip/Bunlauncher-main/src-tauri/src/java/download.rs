use crate::error::set_global_error;
use crate::utils::fetchmanifest::build_download_client;
use crate::utils::hash::verify_hash;
use reqwest::header::CONTENT_LENGTH;
use std::fs::{self, File};
use std::io::BufReader;
use std::path::{Path, PathBuf};
use tokio::io::AsyncWriteExt;

pub fn check_extracted_java(dest_path: &str, expected_hash: &str) -> bool {
    let dest_dir = Path::new(dest_path);
    let marker_file = dest_dir.join(".version_hash");
    if let Ok(saved_hash) = fs::read_to_string(&marker_file) {
        if saved_hash.trim().eq_ignore_ascii_case(expected_hash.trim()) {
            return find_java_bin(dest_dir).is_some();
        }
    }
    false
}

pub async fn download_java(url: &str, path: &str, expected_hash: &str) -> bool {
    let target_path = PathBuf::from(path);
    let tmp_path = target_path.with_extension("part");

    if target_path.exists() {
        if verify_hash(path, expected_hash).await.unwrap_or(false) {
            return true;
        }
        let _ = tokio::fs::remove_file(&target_path).await;
    }

    let client = match build_download_client() {
        Ok(c) => c,
        Err(e) => {
            set_global_error(e);
            return false;
        }
    };

    if let Some(parent) = target_path.parent() {
        if let Err(e) = tokio::fs::create_dir_all(parent).await {
            set_global_error(format!("Не удалось создать директорию: {}", e));
            return false;
        }
    }

    for attempt in 0u32..3 {
        let mut start_byte = 0u64;
        if let Ok(meta) = tokio::fs::metadata(&tmp_path).await {
            start_byte = meta.len();
        }

        let mut req = client.get(url);
        if start_byte > 0 {
            req = req.header("Range", format!("bytes={}-", start_byte));
        }

        let response = match req.send().await {
            Ok(r) => r,
            Err(e) => {
                set_global_error(format!(
                    "Ошибка соединения (попытка {}): {}",
                    attempt + 1,
                    e
                ));
                tokio::time::sleep(std::time::Duration::from_secs(2u64.pow(attempt))).await;
                continue;
            }
        };

        let is_partial = response.status() == reqwest::StatusCode::PARTIAL_CONTENT;
        if !response.status().is_success() && !is_partial {
            set_global_error(format!("Сервер вернул ошибку: {}", response.status()));
            return false;
        }

        let expected_size = response
            .headers()
            .get(CONTENT_LENGTH)
            .and_then(|v| v.to_str().ok())
            .and_then(|v| v.parse::<u64>().ok());

        let mut file_opts = tokio::fs::OpenOptions::new();
        file_opts.create(true).write(true);
        if is_partial {
            file_opts.append(true);
        } else {
            file_opts.truncate(true);
        }

        let mut file = match file_opts.open(&tmp_path).await {
            Ok(f) => f,
            Err(e) => {
                set_global_error(format!("Ошибка создания файла: {}", e));
                return false;
            }
        };

        let mut downloaded = 0u64;
        let mut response = response;
        let mut write_ok = true;

        loop {
            match response.chunk().await {
                Ok(Some(chunk)) => {
                    if file.write_all(&chunk).await.is_err() {
                        write_ok = false;
                        break;
                    }
                    downloaded += chunk.len() as u64;
                }
                Ok(None) => break,
                Err(e) => {
                    set_global_error(format!("Ошибка чтения потока: {}", e));
                    write_ok = false;
                    break;
                }
            }
        }

        let _ = file.flush().await;
        let _ = file.sync_all().await;
        drop(file);

        if !write_ok {
            tokio::time::sleep(std::time::Duration::from_secs(2u64.pow(attempt))).await;
            continue;
        }

        if let Some(expected) = expected_size {
            let actual = if is_partial {
                start_byte + downloaded
            } else {
                downloaded
            };
            if expected > 0 && actual < expected {
                tokio::time::sleep(std::time::Duration::from_secs(2u64.pow(attempt))).await;
                continue;
            }
        }

        if !verify_hash(tmp_path.to_str().unwrap_or(""), expected_hash)
            .await
            .unwrap_or(false)
        {
            set_global_error("Проверка контрольной суммы Java не прошла".to_string());
            let _ = tokio::fs::remove_file(&tmp_path).await;
            return false;
        }

        let _ = tokio::fs::remove_file(&target_path).await;
        if tokio::fs::rename(&tmp_path, &target_path).await.is_ok() {
            return true;
        }
    }

    let _ = tokio::fs::remove_file(&tmp_path).await;
    set_global_error("Не удалось загрузить Java после нескольких попыток".to_string());
    false
}

pub fn extract_java(
    archive_path: &str,
    dest_path: &str,
    expected_hash: &str,
) -> Result<(), String> {
    let archive_path = PathBuf::from(archive_path)
        .canonicalize()
        .unwrap_or_else(|_| PathBuf::from(archive_path));
    let dest_dir = Path::new(dest_path);

    if dest_dir.exists() {
        fs::remove_dir_all(dest_dir)
            .map_err(|e| format!("Не удалось очистить директорию Java: {}", e))?;
    }
    fs::create_dir_all(dest_dir).map_err(|e| format!("Не удалось создать папку Java: {}", e))?;

    let file = File::open(&archive_path).map_err(|e| format!("Не удалось открыть архив: {}", e))?;
    let reader = BufReader::with_capacity(1024 * 1024, file);
    let archive_name = archive_path.to_string_lossy().to_lowercase();

    if archive_name.ends_with(".zip") {
        let mut archive = zip::ZipArchive::new(reader).map_err(|e| format!("Ошибка ZIP: {}", e))?;
        for index in 0..archive.len() {
            let mut entry = archive
                .by_index(index)
                .map_err(|e| format!("Ошибка ZIP entry: {}", e))?;
            let enclosed = match entry.enclosed_name() {
                Some(p) => p.to_owned(),
                None => continue,
            };
            let out_path = dest_dir.join(enclosed);
            if entry.is_dir() {
                fs::create_dir_all(&out_path)
                    .map_err(|e| format!("Ошибка создания директории: {}", e))?;
                continue;
            }
            if let Some(parent) = out_path.parent() {
                fs::create_dir_all(parent)
                    .map_err(|e| format!("Ошибка создания директории: {}", e))?;
            }
            let mut out_file =
                File::create(&out_path).map_err(|e| format!("Ошибка создания файла: {}", e))?;
            std::io::copy(&mut entry, &mut out_file)
                .map_err(|e| format!("Ошибка распаковки ZIP: {}", e))?;
            #[cfg(unix)]
            {
                use std::os::unix::fs::PermissionsExt;
                if let Some(mode) = entry.unix_mode() {
                    let _ = fs::set_permissions(&out_path, fs::Permissions::from_mode(mode));
                }
            }
        }
    } else if archive_name.ends_with(".tar.gz") {
        let tar = flate2::read::GzDecoder::new(reader);
        let mut archive = tar::Archive::new(tar);
        let entries = archive
            .entries()
            .map_err(|e| format!("Ошибка TAR: {}", e))?;
        for entry in entries {
            let mut entry = entry.map_err(|e| format!("Ошибка TAR entry: {}", e))?;
            entry
                .unpack_in(dest_dir)
                .map_err(|e| format!("Ошибка распаковки TAR: {}", e))?;
        }
    } else {
        return Err("Неподдерживаемый формат архива".to_string());
    }

    if find_java_bin(dest_dir).is_none() {
        return Err("После распаковки не найден бинарник Java".to_string());
    }

    let marker_file = dest_dir.join(".version_hash");
    fs::write(&marker_file, expected_hash)
        .map_err(|e| format!("Не удалось сохранить маркер Java: {}", e))?;
    let _ = fs::remove_file(&archive_path);
    Ok(())
}

pub fn find_java_bin(base: &Path) -> Option<PathBuf> {
    #[cfg(target_os = "windows")]
    let bin_name = "java.exe";
    #[cfg(not(target_os = "windows"))]
    let bin_name = "java";

    let candidates = [
        base.join("bin").join(bin_name),
        base.join("jre").join("bin").join(bin_name),
        base.join("Contents")
            .join("Home")
            .join("bin")
            .join(bin_name),
    ];
    for candidate in &candidates {
        if candidate.is_file() {
            return Some(candidate.clone());
        }
    }
    if let Ok(entries) = fs::read_dir(base) {
        for entry in entries.flatten() {
            let path = entry.path();
            if !path.is_dir() {
                continue;
            }
            let nested = [
                path.join("bin").join(bin_name),
                path.join("jre").join("bin").join(bin_name),
                path.join("Contents")
                    .join("Home")
                    .join("bin")
                    .join(bin_name),
            ];
            for candidate in &nested {
                if candidate.is_file() {
                    return Some(candidate.clone());
                }
            }
        }
    }
    None
}
