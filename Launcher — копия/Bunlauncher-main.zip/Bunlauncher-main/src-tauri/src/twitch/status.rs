use reqwest;
use serde::Serialize;
use std::collections::HashMap;

#[derive(Serialize)]
struct TwitchStatus(HashMap<String, bool>);

#[tauri::command]
pub async fn check_broadcast(logins: Vec<String>) -> Result<HashMap<String, bool>, String> {
    let mut results = HashMap::new();

    for login in logins {
        let clean_login = login.trim().to_lowercase();
        if clean_login.is_empty() {
            continue;
        }

        let url = format!("https://www.twitch.tv/{}", clean_login);

        let is_live = match reqwest::get(&url).await {
            Ok(resp) => {
                match resp.text().await {
                    Ok(body) => {
                        // Более надёжные паттерны для определения стрима
                        body.contains("\"isLiveBroadcast\":true")
                            || body.contains("\"isLive\":true")
                            || body.contains(&format!("\"channelLogin\":\"{}\"", clean_login))
                                && body.contains("Live")
                    }
                    Err(e) => {
                        eprintln!(
                            "[Twitch] Failed to read response for {}: {}",
                            clean_login, e
                        );
                        false
                    }
                }
            }
            Err(e) => {
                eprintln!("[Twitch] Failed to fetch {}: {}", url, e);
                false
            }
        };

        results.insert(clean_login, is_live);

        tokio::time::sleep(tokio::time::Duration::from_millis(300)).await;
    }

    Ok(results)
}
