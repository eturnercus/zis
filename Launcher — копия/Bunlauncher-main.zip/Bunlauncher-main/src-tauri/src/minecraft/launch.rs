use anyhow::{anyhow, Result};
use std::collections::{HashMap, HashSet};
use std::fs::File;
use std::io;
use std::path::{Path, PathBuf};

#[derive(Debug, Clone, Copy, PartialEq)]
enum Os {
    Windows,
    Linux,
    Mac,
}

pub fn build_launch_command(
    java_path: &str,
    game_dir: &Path,
    username: &str,
    uuid: Option<&str>,
    launcher_name: &str,
    launcher_version: &str,
    ram_mb: usize,
    width: u32,
    height: u32,
) -> Result<Vec<String>> {
    let os = if cfg!(target_os = "windows") {
        Os::Windows
    } else if cfg!(target_os = "linux") {
        Os::Linux
    } else if cfg!(target_os = "macos") {
        Os::Mac
    } else {
        return Err(anyhow!("Unsupported OS"));
    };

    let vanilla_path = game_dir.join("versions").join("1.21.1").join("1.21.1.json");
    let neoforge_path = game_dir
        .join("versions")
        .join("neoforge-21.1.233")
        .join("neoforge-21.1.233.json");

    let vanilla_str = std::fs::read_to_string(&vanilla_path)
        .map_err(|e| anyhow!("Failed to read vanilla manifest: {}", e))?;
    let neoforge_str = std::fs::read_to_string(&neoforge_path)
        .map_err(|e| anyhow!("Failed to read neoforge manifest: {}", e))?;

    let neoforge: serde_json::Value = serde_json::from_str(&neoforge_str)?;
    let vanilla: serde_json::Value = serde_json::from_str(&vanilla_str)?;

    let library_dir = game_dir.join("libraries");
    let natives_dir = game_dir.join("versions").join("1.21.1").join("natives");
    let assets_root = game_dir.join("assets");
    let assets_index_name = vanilla["assetIndex"]["id"]
        .as_str()
        .unwrap_or("17")
        .to_string();
    let cp_sep = if cfg!(target_os = "windows") {
        ";"
    } else {
        ":"
    };
    let auth_uuid = uuid
        .unwrap_or("00000000-0000-0000-0000-000000000000")
        .to_string();

    let client_jar = game_dir.join("versions").join("1.21.1").join("1.21.1.jar");
    if !client_jar.exists() {
        return Err(anyhow!("Client JAR not found at {}", client_jar.display()));
    }

    // Classpath из манифестов
    let mut classpath_entries: Vec<PathBuf> = Vec::new();
    let mut seen: HashSet<String> = HashSet::new();
    seen.insert(client_jar.to_string_lossy().to_string());
    classpath_entries.push(client_jar.clone());

    for libs_json in [&neoforge["libraries"], &vanilla["libraries"]] {
        let Some(libs) = libs_json.as_array() else {
            continue;
        };
        for lib in libs {
            if let Some(rules) = lib.get("rules") {
                if !should_include(rules, os, &HashMap::new())? {
                    continue;
                }
            }
            if let Some(path) = lib
                .get("downloads")
                .and_then(|d| d.get("artifact"))
                .and_then(|a| a.get("path"))
                .and_then(|p| p.as_str())
            {
                let full = library_dir.join(path);
                if full.exists() {
                    let s = full.to_string_lossy().to_string();
                    if seen.insert(s) {
                        classpath_entries.push(full);
                    }
                }
            }
        }
    }

    // Извлекаем нативы — используем версии из манифеста
    prepare_natives(&vanilla, &neoforge, &library_dir, &natives_dir, os)?;

    // -p
    let mut neoforge_module_path = None;
    if let Some(arr) = neoforge["arguments"]["jvm"].as_array() {
        let mut i = 0;
        while i < arr.len() {
            if let Some(s) = arr[i].as_str() {
                if s == "-p" || s == "--module-path" {
                    if i + 1 < arr.len() {
                        if let Some(v) = arr[i + 1].as_str() {
                            neoforge_module_path = Some(v.to_string());
                        }
                    }
                    i += 2;
                    continue;
                }
            }
            i += 1;
        }
    }
    let neoforge_module_path = neoforge_module_path
        .ok_or_else(|| anyhow!("Could not find -p argument in NeoForge manifest"))?;

    let classpath_str = classpath_entries
        .iter()
        .map(|p| p.to_string_lossy().to_string())
        .collect::<Vec<_>>()
        .join(cp_sep);

    let mut subs = HashMap::new();
    subs.insert(
        "library_directory".to_string(),
        path_to_string(&library_dir),
    );
    subs.insert("classpath_separator".to_string(), cp_sep.to_string());
    subs.insert("version_name".to_string(), "1.21.1".to_string());
    subs.insert(
        "natives_directory".to_string(),
        path_to_string(&natives_dir),
    );
    subs.insert("game_directory".to_string(), path_to_string(game_dir));
    subs.insert("assets_root".to_string(), path_to_string(&assets_root));
    subs.insert("assets_index_name".to_string(), assets_index_name);
    subs.insert("auth_player_name".to_string(), username.to_string());
    subs.insert("auth_uuid".to_string(), auth_uuid);
    subs.insert("auth_access_token".to_string(), "0".to_string());
    subs.insert("clientid".to_string(), String::new());
    subs.insert("auth_xuid".to_string(), String::new());
    subs.insert("user_type".to_string(), "mojang".to_string());
    subs.insert("version_type".to_string(), "release".to_string());
    subs.insert("launcher_name".to_string(), launcher_name.to_string());
    subs.insert("launcher_version".to_string(), launcher_version.to_string());
    subs.insert("classpath".to_string(), classpath_str.clone());
    subs.insert("resolution_width".to_string(), width.to_string());
    subs.insert("resolution_height".to_string(), height.to_string());

    let substitute = |s: &str| -> String {
        let mut res = s.to_string();
        for (k, v) in &subs {
            res = res.replace(&format!("${{{}}}", k), v);
        }
        res
    };

    let mut jvm_args: Vec<String> = vec![
        format!("-Xmx{}M", ram_mb),
        "-Xms512M".into(),
        "-XX:+UseZGC".into(),
        "-XX:+ZGenerational".into(),
        "-XX:+UnlockExperimentalVMOptions".into(),
        "-XX:+DisableExplicitGC".into(),
        "-XX:+AlwaysPreTouch".into(),
        "-XX:+ParallelRefProcEnabled".into(),
        "-XX:MaxInlineLevel=15".into(),
        "-Dfile.encoding=UTF-8".into(),
        "-Djava.rmi.server.useCodebaseOnly=true".into(),
        "-Dcom.sun.jndi.rmi.object.trustURLCodebase=false".into(),
        "-Dcom.sun.jndi.cosnaming.object.trustURLCodebase=false".into(),
        "-Dlog4j2.formatMsgNoLookups=true".into(),
        "-Djava.awt.headless=false".into(),
        "-Djava.net.preferIPv4Stack=true".into(),
        format!("-Dminecraft.client.jar={}", path_to_string(&client_jar)),
        "-Dfml.ignoreInvalidMinecraftCertificates=true".into(),
        "-Dfml.ignorePatchDiscrepancies=true".into(),
        format!("-DlegacyClassPath={}", classpath_str),
        format!("-Djava.library.path={}", path_to_string(&natives_dir)),
        format!("-Dorg.lwjgl.librarypath={}", path_to_string(&natives_dir)),
    ];

    jvm_args.push("-p".into());
    jvm_args.push(substitute(&neoforge_module_path));

    if let Some(arr) = neoforge["arguments"]["jvm"].as_array() {
        let mut i = 0;
        while i < arr.len() {
            if let Some(s) = arr[i].as_str() {
                if s == "-p" || s == "--module-path" {
                    i += 2;
                    continue;
                }
                jvm_args.push(substitute(s));
            }
            i += 1;
        }
    }

    if let Some(arr) = vanilla["arguments"]["jvm"].as_array() {
        for arg in arr {
            match arg {
                serde_json::Value::String(s) => {
                    jvm_args.push(substitute(s));
                }
                serde_json::Value::Object(obj) => {
                    if let (Some(rules), Some(value)) = (obj.get("rules"), obj.get("value")) {
                        if should_include(rules, os, &HashMap::new())? {
                            match value {
                                serde_json::Value::String(s) => {
                                    jvm_args.push(substitute(s));
                                }
                                serde_json::Value::Array(arr) => {
                                    for v in arr {
                                        if let serde_json::Value::String(s) = v {
                                            jvm_args.push(substitute(s));
                                        }
                                    }
                                }
                                _ => {}
                            }
                        }
                    }
                }
                _ => {}
            }
        }
    }

    if let Some(logging) = vanilla.get("logging") {
        if let Some(client) = logging.get("client") {
            if let Some(arg) = client.get("argument").and_then(|a| a.as_str()) {
                if let Some(file_id) = client
                    .get("file")
                    .and_then(|f| f.get("id"))
                    .and_then(|id| id.as_str())
                {
                    let log_config = assets_root.join("log_configs").join(file_id);
                    jvm_args.push(arg.replace("${path}", &path_to_string(&log_config)));
                }
            }
        }
    }

    let mut game_args: Vec<String> = Vec::new();

    if let Some(arr) = neoforge["arguments"]["game"].as_array() {
        for arg in arr {
            if let Some(s) = arg.as_str() {
                game_args.push(substitute(s));
            }
        }
    }

    if let Some(arr) = vanilla["arguments"]["game"].as_array() {
        for arg in arr {
            match arg {
                serde_json::Value::String(s) => {
                    game_args.push(substitute(s));
                }
                serde_json::Value::Object(obj) => {
                    if let (Some(rules), Some(value)) = (obj.get("rules"), obj.get("value")) {
                        if should_include(rules, os, &HashMap::new())? {
                            match value {
                                serde_json::Value::String(s) => game_args.push(substitute(s)),
                                serde_json::Value::Array(arr) => {
                                    for v in arr {
                                        if let serde_json::Value::String(s) = v {
                                            game_args.push(substitute(s));
                                        }
                                    }
                                }
                                _ => {}
                            }
                        }
                    }
                }
                _ => {}
            }
        }
    }

    let main_class = neoforge["mainClass"]
        .as_str()
        .unwrap_or("cpw.mods.bootstraplauncher.BootstrapLauncher")
        .to_string();

    let mut command = vec![java_path.to_string()];
    command.extend(jvm_args);
    command.push(main_class);
    command.extend(game_args);

    Ok(command)
}

// ─── Natives ─────────────────────────────────────────────────────────────────

fn prepare_natives(
    vanilla: &serde_json::Value,
    neoforge: &serde_json::Value,
    library_dir: &Path,
    natives_dir: &Path,
    os: Os,
) -> Result<()> {
    if natives_dir.exists() {
        std::fs::remove_dir_all(natives_dir)?;
    }
    std::fs::create_dir_all(natives_dir)?;

    let os_tag = match os {
        Os::Linux => "natives-linux",
        Os::Windows => "natives-windows",
        Os::Mac => "natives-macos",
    };

    let mut allowed_versions: HashMap<String, String> = HashMap::new();

    for manifest in [vanilla, neoforge] {
        let Some(libs) = manifest["libraries"].as_array() else {
            continue;
        };
        for lib in libs {
            if let Some(rules) = lib.get("rules") {
                if !should_include(rules, os, &HashMap::new()).unwrap_or(false) {
                    continue;
                }
            }
            if let Some(name) = lib["name"].as_str() {
                // name формат: "group:artifact:version"
                let parts: Vec<&str> = name.splitn(3, ':').collect();
                if parts.len() >= 3 {
                    let group = parts[0].to_string();
                    let version = parts[2].split(':').next().unwrap_or(parts[2]).to_string();
                    // Запоминаем версию по группе+артефакту
                    let key = format!("{}:{}", parts[0], parts[1]);
                    allowed_versions.insert(key, version);
                }
            }
        }
    }

    eprintln!(
        "[LAUNCHER] allowed_versions from manifests: {:?}",
        allowed_versions
    );

    let mut extracted: HashSet<String> = HashSet::new();

    // Шаг 2: сканируем папки natives-{os}, но извлекаем JAR только нужной версии
    scan_and_extract_versioned(
        library_dir,
        natives_dir,
        os_tag,
        &allowed_versions,
        &mut extracted,
    )?;

    eprintln!("[LAUNCHER] natives dir after extraction:");
    if let Ok(entries) = std::fs::read_dir(natives_dir) {
        for e in entries.flatten() {
            eprintln!("  {}", e.file_name().to_string_lossy());
        }
    }

    Ok(())
}

fn scan_and_extract_versioned(
    root: &Path,
    natives_dir: &Path,
    os_tag: &str,
    allowed_versions: &HashMap<String, String>,
    extracted: &mut HashSet<String>,
) -> Result<()> {
    let Ok(rd) = std::fs::read_dir(root) else {
        return Ok(());
    };

    for entry in rd.flatten() {
        let path = entry.path();
        if !path.is_dir() {
            continue;
        }

        let dir_name = path.file_name().and_then(|n| n.to_str()).unwrap_or("");

        if dir_name.contains(os_tag) {
            // Это папка с нативами, например "lwjgl-natives-linux"
            // Из неё имя артефакта — это dir_name, а группу нужно определить по пути
            // Ищем совпадение версии: смотрим подпапки (это версии)
            extract_versioned_jars(&path, dir_name, natives_dir, allowed_versions, extracted)?;
        } else {
            scan_and_extract_versioned(&path, natives_dir, os_tag, allowed_versions, extracted)?;
        }
    }

    Ok(())
}

fn extract_versioned_jars(
    artifact_dir: &Path,
    artifact_name: &str,
    natives_dir: &Path,
    allowed_versions: &HashMap<String, String>,
    extracted: &mut HashSet<String>,
) -> Result<()> {
    // Определяем группу из пути: libraries/org/lwjgl/lwjgl-natives-linux -> "org.lwjgl"
    let group = infer_group_from_path(artifact_dir);

    let key = format!("{}:{}", group, artifact_name);
    // Ищем разрешённую версию. Если не нашли точное совпадение — берём любую версию
    let allowed_ver = allowed_versions.get(&key).cloned();

    eprintln!(
        "[LAUNCHER] native artifact: {}, group: {}, key: {}, allowed_ver: {:?}",
        artifact_name, group, key, allowed_ver
    );

    let Ok(rd) = std::fs::read_dir(artifact_dir) else {
        return Ok(());
    };

    let mut version_dirs: Vec<PathBuf> = rd
        .flatten()
        .filter(|e| e.path().is_dir())
        .map(|e| e.path())
        .collect();

    if let Some(ref ver) = allowed_ver {
        // Оставляем только нужную версию
        version_dirs.retain(|p| p.file_name().and_then(|n| n.to_str()) == Some(ver.as_str()));
    } else {
        // Нет точного совпадения — берём самую старую (наименьшую) версию,
        // чтобы соответствовать тому что в classpath
        version_dirs.sort();
        version_dirs.truncate(1);
    }

    for ver_dir in version_dirs {
        let ver_name = ver_dir.file_name().and_then(|n| n.to_str()).unwrap_or("?");
        let Ok(rd2) = std::fs::read_dir(&ver_dir) else {
            continue;
        };

        for entry in rd2.flatten() {
            let path = entry.path();
            if path.extension().and_then(|e| e.to_str()) != Some("jar") {
                continue;
            }

            let key = path.to_string_lossy().to_string();
            if !extracted.insert(key.clone()) {
                continue;
            }

            eprintln!("[LAUNCHER] Extracting (v{}): {}", ver_name, path.display());
            match extract_native_jar(&path, natives_dir) {
                Ok(n) => eprintln!("[LAUNCHER]   -> {} files", n),
                Err(e) => eprintln!("[LAUNCHER]   -> ERROR: {}", e),
            }
        }
    }

    Ok(())
}

/// Угадывает Maven-группу из абсолютного пути папки артефакта.
/// Например: .../libraries/org/lwjgl/lwjgl-natives-linux -> "org.lwjgl"
fn infer_group_from_path(artifact_dir: &Path) -> String {
    // Ищем компонент "libraries" в пути, берём то что между ним и последним компонентом
    let components: Vec<&str> = artifact_dir
        .components()
        .filter_map(|c| c.as_os_str().to_str())
        .collect();

    if let Some(lib_idx) = components.iter().rposition(|&c| c == "libraries") {
        // Берём всё между "libraries" и последним компонентом (именем артефакта)
        let group_parts = &components[lib_idx + 1..components.len() - 1];
        return group_parts.join(".");
    }

    String::new()
}

fn extract_native_jar(jar_path: &Path, natives_dir: &Path) -> Result<usize> {
    let file = File::open(jar_path)?;
    let mut archive = zip::ZipArchive::new(file)?;
    let mut count = 0;

    for i in 0..archive.len() {
        let mut entry = match archive.by_index(i) {
            Ok(e) => e,
            Err(_) => continue,
        };
        if entry.is_dir() {
            continue;
        }

        let name = entry.name().replace('\\', "/");
        if !name.ends_with(".so") && !name.ends_with(".dll") && !name.ends_with(".dylib") {
            continue;
        }

        let file_name = match name.rsplit('/').next() {
            Some(n) if !n.is_empty() => n,
            _ => continue,
        };

        let out_path = natives_dir.join(file_name);
        let mut out = File::create(&out_path)?;
        io::copy(&mut entry, &mut out)?;
        count += 1;

        #[cfg(unix)]
        {
            use std::os::unix::fs::PermissionsExt;
            let _ = std::fs::set_permissions(&out_path, std::fs::Permissions::from_mode(0o755));
        }
    }

    Ok(count)
}

// ─── Helpers ─────────────────────────────────────────────────────────────────

fn should_include(
    rules: &serde_json::Value,
    os: Os,
    features: &HashMap<String, bool>,
) -> Result<bool> {
    let rules = rules.as_array().ok_or_else(|| anyhow!("rules not array"))?;
    let mut allowed = false;

    for rule_val in rules {
        let rule = rule_val
            .as_object()
            .ok_or_else(|| anyhow!("rule not object"))?;
        let action = rule
            .get("action")
            .and_then(|a| a.as_str())
            .unwrap_or("allow");
        let mut matches = true;

        if let Some(os_rule) = rule.get("os") {
            let os_obj = os_rule
                .as_object()
                .ok_or_else(|| anyhow!("os rule not object"))?;
            if let Some(name_v) = os_obj.get("name").and_then(|n| n.as_str()) {
                matches &= match os {
                    Os::Windows => name_v == "windows",
                    Os::Linux => name_v == "linux",
                    Os::Mac => name_v == "osx",
                };
            }
            if let Some(arch) = os_obj.get("arch").and_then(|a| a.as_str()) {
                let current_arch = if cfg!(target_arch = "x86") {
                    "x86"
                } else if cfg!(target_arch = "x86_64") {
                    "x86_64"
                } else {
                    std::env::consts::ARCH
                };
                matches &= current_arch == arch;
            }
        }

        if let Some(feat_rule) = rule.get("features") {
            let feat_obj = feat_rule
                .as_object()
                .ok_or_else(|| anyhow!("features not object"))?;
            for (feat, required) in feat_obj {
                let required = required.as_bool().unwrap_or(false);
                let has = features.get(feat).copied().unwrap_or(false);
                matches &= has == required;
            }
        }

        if matches {
            allowed = action == "allow";
        }
    }

    Ok(allowed)
}

fn path_to_string(path: &Path) -> String {
    path.to_str().unwrap_or("").to_string()
}
