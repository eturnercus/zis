use crate::emit_launch;
use futures::future::join_all;
use reqwest::{Client, StatusCode};
use serde::Deserialize;
use std::collections::HashMap;
use std::path::{Path, PathBuf};
use std::sync::Arc;
use tauri::AppHandle;
use tokio::fs;
use tokio::io::AsyncWriteExt;
use tokio::sync::Semaphore;

#[derive(Deserialize, Debug, Clone)]
pub struct IndexManifest {
    #[serde(default)]
    pub archives: HashMap<String, ArchiveEntry>,
    #[serde(default)]
    pub files: HashMap<String, FileEntry>,
}

#[derive(Deserialize, Debug, Clone)]
pub struct ArchiveEntry {
    pub hash: String,
    pub size: u64,
    pub url: String,
    #[serde(default)]
    pub extract_to: String,
    pub dir_size: Option<u64>,
    #[serde(default)]
    pub items: Vec<String>,
}

#[derive(Deserialize, Debug, Clone)]
pub struct FileEntry {
    pub hash: String,
    pub size: u64,
    pub url: String,
}

fn normalize_path(path: &str) -> String {
    path.replace('\\', "/")
}

async fn dir_items_size(base: &Path, items: &[String]) -> u64 {
    let base = base.to_path_buf();
    let items = items.to_vec();
    tokio::task::spawn_blocking(move || {
        let mut total = 0u64;
        for item in &items {
            let p = base.join(normalize_path(item));
            if p.is_file() {
                total += std::fs::metadata(&p).map(|m| m.len()).unwrap_or(0);
            } else if p.is_dir() {
                let mut stack = vec![p];
                while let Some(dir) = stack.pop() {
                    let Ok(rd) = std::fs::read_dir(&dir) else {
                        continue;
                    };
                    for e in rd.flatten() {
                        let cp = e.path();
                        if cp.is_dir() {
                            stack.push(cp);
                        } else {
                            total += e.metadata().map(|m| m.len()).unwrap_or(0);
                        }
                    }
                }
            }
        }
        total
    })
    .await
    .unwrap_or(0)
}

async fn download_file(client: &Client, url: &str, dest: &Path) -> Result<(), String> {
    if let Some(parent) = dest.parent() {
        fs::create_dir_all(parent)
            .await
            .map_err(|e| format!("mkdir {}: {}", parent.display(), e))?;
    }

    let resp = client
        .get(url)
        .send()
        .await
        .map_err(|e| format!("GET {}: {}", url, e))?;

    if resp.status() != StatusCode::OK {
        return Err(format!("HTTP {} для {}", resp.status(), url));
    }

    let mut f = fs::File::create(dest)
        .await
        .map_err(|e| format!("Создание файла {}: {}", dest.display(), e))?;

    use futures::StreamExt;
    let mut stream = resp.bytes_stream();
    while let Some(chunk) = stream.next().await {
        let chunk = chunk.map_err(|e| format!("Чтение чанка {}: {}", url, e))?;
        f.write_all(&chunk)
            .await
            .map_err(|e| format!("Запись {}: {}", dest.display(), e))?;
    }

    f.flush()
        .await
        .map_err(|e| format!("Flush {}: {}", dest.display(), e))?;

    Ok(())
}

fn extract_zip(archive_path: &Path, dest_dir: &Path) -> Result<(), String> {
    let file = std::fs::File::open(archive_path)
        .map_err(|e| format!("Открытие архива {}: {}", archive_path.display(), e))?;

    let mut zip = zip::ZipArchive::new(file)
        .map_err(|e| format!("Чтение zip {}: {}", archive_path.display(), e))?;

    for i in 0..zip.len() {
        let mut entry = zip
            .by_index(i)
            .map_err(|e| format!("Запись #{}: {}", i, e))?;

        let rel = normalize_path(entry.name());
        if rel.contains("..") {
            continue;
        }

        let out = dest_dir.join(&rel);

        if entry.is_dir() {
            std::fs::create_dir_all(&out).map_err(|e| format!("mkdir {}: {}", out.display(), e))?;
        } else {
            if let Some(p) = out.parent() {
                std::fs::create_dir_all(p).map_err(|e| format!("mkdir {}: {}", p.display(), e))?;
            }
            let mut outfile = std::fs::File::create(&out)
                .map_err(|e| format!("Создание {}: {}", out.display(), e))?;
            let mut buf = std::io::BufWriter::new(&mut outfile);
            std::io::copy(&mut entry, &mut buf)
                .map_err(|e| format!("Копирование {}: {}", out.display(), e))?;
        }
    }
    Ok(())
}

async fn process_archive(
    client: Arc<Client>,
    game_dir: PathBuf,
    name: String,
    entry: ArchiveEntry,
    dl_sem: Arc<Semaphore>,
) -> Result<(), String> {
    let extract_dir = if entry.extract_to.is_empty() {
        game_dir.clone()
    } else {
        game_dir.join(normalize_path(&entry.extract_to))
    };

    let is_preserve = name == "shaderpacks.zip" || name == "resourcepacks.zip";

    let needs_update = if is_preserve {
        // Проверяем только наличие самой папки, игнорируем хэши и размеры
        !entry
            .items
            .iter()
            .all(|item| extract_dir.join(normalize_path(item)).exists())
    } else {
        match entry.dir_size {
            Some(expected) => {
                let actual = dir_items_size(&extract_dir, &entry.items).await;
                actual != expected
            }
            None => !entry
                .items
                .iter()
                .all(|item| extract_dir.join(normalize_path(item)).exists()),
        }
    };

    if !needs_update {
        return Ok(());
    }

    let _permit = dl_sem.acquire().await.map_err(|e| e.to_string())?;

    let tmp = game_dir.join(format!(".tmp_{}", name));
    download_file(&client, &entry.url, &tmp).await?;

    let valid = crate::utils::hash::verify_hash(tmp.to_str().unwrap_or(""), &entry.hash)
        .await
        .unwrap_or(false);

    if !valid {
        let _ = fs::remove_file(&tmp).await;
        return Err(format!("SHA256 архива {} не совпал", name));
    }

    fs::create_dir_all(&extract_dir)
        .await
        .map_err(|e| format!("mkdir {}: {}", extract_dir.display(), e))?;

    let tmp2 = tmp.clone();
    let ed2 = extract_dir.clone();
    tokio::task::spawn_blocking(move || extract_zip(&tmp2, &ed2))
        .await
        .map_err(|e| format!("Spawn распаковки: {}", e))??;

    let _ = fs::remove_file(&tmp).await;
    Ok(())
}

async fn process_file(
    client: Arc<Client>,
    game_dir: PathBuf,
    rel_path: String,
    entry: FileEntry,
    dl_sem: Arc<Semaphore>,
) -> Result<(), String> {
    let dest = game_dir.join(normalize_path(&rel_path));
    let is_mod = rel_path.starts_with("mods/") || rel_path.starts_with("mods\\");
    let is_options = rel_path == "options.txt";

    if dest.exists() {
        if is_options {
            // Проверяем только наличие, игнорируем изменения пользователя
            return Ok(());
        }

        if is_mod {
            let ok = crate::utils::hash::verify_hash(dest.to_str().unwrap_or(""), &entry.hash)
                .await
                .unwrap_or(false);
            if ok {
                return Ok(());
            }
            let _ = fs::remove_file(&dest).await;
        } else if let Ok(meta) = fs::metadata(&dest).await {
            if meta.len() == entry.size {
                return Ok(());
            }
        }
    }

    let _permit = dl_sem.acquire().await.map_err(|e| e.to_string())?;

    download_file(&client, &entry.url, &dest).await?;

    if is_mod {
        let ok = crate::utils::hash::verify_hash(dest.to_str().unwrap_or(""), &entry.hash)
            .await
            .unwrap_or(false);
        if !ok {
            let _ = fs::remove_file(&dest).await;
            return Err(format!("SHA1 мода {} не совпал после загрузки", rel_path));
        }
    }

    Ok(())
}

pub async fn sync_and_download_game(
    game_dir: &Path,
    manifest: &IndexManifest,
    app: &AppHandle,
) -> Result<(), String> {
    let client = Arc::new(crate::utils::fetchmanifest::build_download_client()?);

    fs::create_dir_all(game_dir)
        .await
        .map_err(|e| format!("mkdir game_dir: {}", e))?;

    let archive_sem = Arc::new(Semaphore::new(2));
    let file_sem = Arc::new(Semaphore::new(8));

    emit_launch(app, "Проверка архивов...", 56);

    let archive_tasks: Vec<_> = manifest
        .archives
        .iter()
        .map(|(name, entry)| {
            process_archive(
                Arc::clone(&client),
                game_dir.to_path_buf(),
                name.clone(),
                entry.clone(),
                Arc::clone(&archive_sem),
            )
        })
        .collect();

    for result in join_all(archive_tasks).await {
        result?;
    }

    emit_launch(app, "Проверка модов и файлов...", 70);

    let file_tasks: Vec<_> = manifest
        .files
        .iter()
        .map(|(rel, entry)| {
            process_file(
                Arc::clone(&client),
                game_dir.to_path_buf(),
                rel.clone(),
                entry.clone(),
                Arc::clone(&file_sem),
            )
        })
        .collect();

    for result in join_all(file_tasks).await {
        result?;
    }

    Ok(())
}
