use std::sync::RwLock;

pub static GLOBAL_ERROR: RwLock<Option<String>> = RwLock::new(None);

pub fn set_global_error(msg: String) {
    eprintln!("[ERROR] {}", msg);
    if let Ok(mut guard) = GLOBAL_ERROR.write() {
        *guard = Some(msg);
    }
}
