import { defineConfig } from "vite";
import react from "@vitejs/plugin-react";
import tailwindcss from "@tailwindcss/vite";

export default defineConfig({
  plugins: [react(), tailwindcss()],
  clearScreen: false,
  publicDir: "public",
  server: {
    port: 1420,
    strictPort: true,
    host: true,
    watch: {
      ignored: ["**/src-tauri/**"],
    },
  },
  envPrefix: ["VITE_", "TAURI_"],
  base: "./",
  build: {
    outDir: "dist",
    emptyOutDir: true,
    target: ["es2021", "chrome100", "safari13"],
    sourcemap: false,
    assetsDir: "assets",
  },
});
