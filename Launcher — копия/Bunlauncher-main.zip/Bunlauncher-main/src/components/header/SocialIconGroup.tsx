import { useState } from "react";
import { openUrl } from "@tauri-apps/plugin-opener";

function openLink(url: string) {
  openUrl(url).catch(console.error);
}

type SocialItem = { label: string; href: string };
type SocialGroup = {
  kind: string;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  items: SocialItem[];
};

export function SocialIconGroup({ group }: { group: SocialGroup }) {
  const Icon = group.icon;
  const [open, setOpen] = useState(false);
  const hasMany = group.items.length > 1;

  if (!hasMany) {
    return (
      <button
        onClick={() => openLink(group.items[0].href)}
        className="w-9 h-9 grid place-items-center rounded-xl bg-black/20 border border-white/10 text-gray-200/80 hover:text-white hover:bg-black/30 transition cursor-pointer"
        aria-label={group.items[0].label}
      >
        <Icon className="w-5 h-5" />
      </button>
    );
  }

  return (
    <div className="relative">
      <button
        onClick={() => setOpen((v) => !v)}
        className="w-9 h-9 grid place-items-center rounded-xl bg-black/20 border border-white/10 text-gray-200/80 hover:text-white hover:bg-black/30 transition cursor-pointer"
        aria-label={group.kind}
        aria-expanded={open}
      >
        <Icon className="w-5 h-5" />
      </button>
      {open && (
        <div className="absolute right-0 mt-2 py-1 w-40 rounded-lg bg-black/90 border border-white/10 shadow-lg z-50">
          {group.items.map((it) => (
            <button
              key={it.href}
              onClick={() => {
                openLink(it.href);
                setOpen(false);
              }}
              className="text-sm text-gray-300 hover:text-white px-3 py-1.5 rounded-lg hover:bg-white/5 transition text-left cursor-pointer w-full"
            >
              {it.label}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
