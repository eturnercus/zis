import { useEffect, useMemo, useState } from "react";
import { RiDiscordLine, RiTelegram2Fill, RiYoutubeLine } from "react-icons/ri";
import { invoke } from "@tauri-apps/api/core";
import { TwitchChip } from "./TwitchChip";
import { SocialIconGroup } from "./SocialIconGroup";

type SocialKind = "telegram" | "youtube" | "discord";
type SocialItem = { label: string; href: string };
type SocialGroup = {
  kind: SocialKind;
  icon: React.ComponentType<React.SVGProps<SVGSVGElement>>;
  items: SocialItem[];
};

const SOCIALS: SocialGroup[] = [
  {
    kind: "telegram",
    icon: RiTelegram2Fill,
    items: [
      { label: "TG1", href: "https://t.me/" },
      { label: "TG2", href: "https://t.me/" },
    ],
  },
  {
    kind: "youtube",
    icon: RiYoutubeLine,
    items: [{ label: "YouTube", href: "https://youtube.com/" }],
  },
  {
    kind: "discord",
    icon: RiDiscordLine,
    items: [{ label: "Discord", href: "https://discord.com/" }],
  },
];

const TWITCH_CHANNELS = [
  {
    login: "cinaminnie",
    label: "cinaminnie",
    avatarUrl: "/images/cinaminnie_icon.png",
  },
  {
    login: "meowlody_note",
    label: "meowlody_note",
    avatarUrl: "/images/meowlody_note_icon.png",
  },
];

export default function Header() {
  const logins = useMemo(() => TWITCH_CHANNELS.map((c) => c.login), []);
  const [liveMap, setLiveMap] = useState<Record<string, boolean>>({});
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;

    const tick = async () => {
      try {
        const result = await invoke<Record<string, boolean>>(
          "check_broadcast",
          { logins },
        );
        if (!cancelled) setLiveMap(result);
      } catch (err) {
        console.error("Failed to fetch Twitch status:", err);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };

    tick();
    const id = setInterval(tick, 30_000);

    return () => {
      cancelled = true;
      clearInterval(id);
    };
  }, [logins]);

  return (
    <header className="flex items-center justify-between px-4 py-2 bg-black/30 backdrop-blur-sm border-b border-white/10">
      <div className="flex items-center gap-2">
        {TWITCH_CHANNELS.map((ch) => (
          <TwitchChip
            key={ch.login}
            {...ch}
            isLive={!!liveMap[ch.login]}
            isLoading={loading}
          />
        ))}
      </div>

      <div className="flex items-center gap-2">
        {SOCIALS.map((g) => (
          <SocialIconGroup key={g.kind} group={g} />
        ))}
      </div>
    </header>
  );
}
