import { openUrl } from "@tauri-apps/plugin-opener";

function openLink(url: string) {
  openUrl(url).catch(console.error);
}

export function TwitchChip({
  login,
  label,
  avatarUrl,
  isLive,
  isLoading,
}: {
  login: string;
  label: string;
  avatarUrl: string;
  isLive: boolean;
  isLoading: boolean;
}) {
  return (
    <button
      onClick={() => openLink(`https://twitch.tv/${login}`)}
      className={`flex items-center gap-1.5 px-2.5 py-1 rounded-full ${isLive ? "bg-[#6441a5] shadow-lg inset-shadow-white shadow-[#6441a5] hover:bg-[#6421a5]" : "bg-black/20 hover:bg-black/30"} border border-white/10  transition cursor-pointer`}
    >
      <img
        src={avatarUrl}
        alt={label}
        className="w-6 h-6 rounded-full object-cover"
        onError={(e) => (e.currentTarget.style.display = "none")}
      />
      <span className="text-sm text-white">{label}</span>
      {isLoading ? (
        <span className="w-1.5 h-1.5 rounded-full bg-gray-500 animate-pulse" />
      ) : (
        <span
          className={`w-1.5 h-1.5 rounded-full ${
            isLive ? "bg-green-500" : "bg-gray-500"
          }`}
        />
      )}
    </button>
  );
}
