import { useLayoutEffect, useMemo, useRef, useState } from "react";
import gsap from "gsap";
import {
  IoFlashOutline,
  IoImagesOutline,
  IoLayersOutline,
  IoSparklesOutline,
} from "react-icons/io5";

type ShaderPreset = {
  id: string;
  name: string;
  mood: string;
  quality: string;
  enabled: boolean;
};

type ResourcePack = {
  id: string;
  name: string;
  resolution: string;
  style: string;
  enabled: boolean;
};

function Toggle({
  checked,
  onClick,
}: {
  checked: boolean;
  onClick: () => void;
}) {
  return (
    <button
      type="button"
      onClick={onClick}
      className={[
        "relative h-8 w-14 rounded-full border transition-all duration-300",
        checked
          ? "border-cyan-300/35 bg-cyan-300/20"
          : "border-white/10 bg-black/15",
      ].join(" ")}
    >
      <span
        className={[
          "absolute top-1 h-6 w-6 rounded-full bg-white shadow-md transition-all duration-300",
          checked ? "left-7" : "left-1",
        ].join(" ")}
      />
    </button>
  );
}

function Resources() {
  const [shaders, setShaders] = useState<ShaderPreset[]>([
    {
      id: "balanced",
      name: "Balanced Glass",
      mood: "Чистая картинка и стабильный FPS",
      quality: "Balanced",
      enabled: true,
    },
    {
      id: "cinematic",
      name: "Cinematic Mist",
      mood: "Мягкий свет, объём и атмосферность",
      quality: "High",
      enabled: false,
    },
    {
      id: "ultra",
      name: "Ultra Bloom",
      mood: "Максимум отражений и глубины",
      quality: "Ultra",
      enabled: false,
    },
  ]);

  const [packs, setPacks] = useState<ResourcePack[]>([
    {
      id: "default+",
      name: "Default+",
      resolution: "16x",
      style: "Ванильный clean-up",
      enabled: true,
    },
    {
      id: "soft-ui",
      name: "Soft UI Pack",
      resolution: "32x",
      style: "Мягкие контрасты и спокойные тона",
      enabled: false,
    },
    {
      id: "medieval",
      name: "Medieval Mood",
      resolution: "64x",
      style: "Более насыщенная RPG-атмосфера",
      enabled: false,
    },
    {
      id: "pbr-lite",
      name: "PBR Lite",
      resolution: "64x",
      style: "Лёгкий физический материал",
      enabled: false,
    },
  ]);

  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!rootRef.current) return;
    gsap.fromTo(
      rootRef.current.querySelectorAll(".resource-card"),
      { opacity: 0, y: 18, scale: 0.99 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.55,
        stagger: 0.06,
        ease: "power3.out",
      },
    );
  }, []);

  const enabledShader = useMemo(
    () => shaders.find((item) => item.enabled),
    [shaders],
  );
  const enabledPacksCount = useMemo(
    () => packs.filter((item) => item.enabled).length,
    [packs],
  );

  const toggleShader = (id: string) => {
    setShaders((current) =>
      current.map((shader) => ({
        ...shader,
        enabled: shader.id === id ? !shader.enabled : false,
      })),
    );
  };

  const togglePack = (id: string) => {
    setPacks((current) =>
      current.map((pack) =>
        pack.id === id ? { ...pack, enabled: !pack.enabled } : pack,
      ),
    );
  };

  return (
    <section
      ref={rootRef}
      className="grid h-full min-h-0 grid-cols-1 gap-[clamp(12px,1.5vw,18px)] xl:grid-rows-[auto_1fr]"
    >
      <div className="grid grid-cols-1 gap-[clamp(12px,1.5vw,18px)] lg:grid-cols-4">
        <div className="resource-card rounded-[26px] border border-white/10 bg-white/8 p-5 shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-cyan-300/12 text-cyan-200">
              <IoFlashOutline size={22} />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">
                Shader
              </div>
              <div className="mt-1 text-white">
                {enabledShader?.name || "Disabled"}
              </div>
            </div>
          </div>
        </div>

        <div className="resource-card rounded-[26px] border border-white/10 bg-white/8 p-5 shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-emerald-300/12 text-emerald-200">
              <IoImagesOutline size={22} />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">
                Resource Packs
              </div>
              <div className="mt-1 text-white">{enabledPacksCount} enabled</div>
            </div>
          </div>
        </div>

        <div className="resource-card rounded-[26px] border border-white/10 bg-white/8 p-5 shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-violet-300/12 text-violet-200">
              <IoLayersOutline size={22} />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">
                Preset
              </div>
              <div className="mt-1 text-white">
                {enabledShader?.quality || "Standard"}
              </div>
            </div>
          </div>
        </div>

        <div className="resource-card rounded-[26px] border border-white/10 bg-white/8 p-5 shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="flex items-center gap-3">
            <div className="flex h-12 w-12 items-center justify-center rounded-2xl border border-white/10 bg-amber-300/12 text-amber-200">
              <IoSparklesOutline size={22} />
            </div>
            <div>
              <div className="text-[11px] uppercase tracking-[0.22em] text-slate-400">
                Mood
              </div>
              <div className="mt-1 text-white">
                {enabledShader?.mood || "Vanilla"}
              </div>
            </div>
          </div>
        </div>
      </div>

      <div className="grid min-h-0 grid-cols-1 gap-[clamp(12px,1.5vw,18px)] 2xl:grid-cols-[420px_1fr]">
        <div className="resource-card min-h-0 overflow-auto rounded-[28px] border border-white/10 bg-white/8 p-[clamp(14px,1.6vw,18px)] shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
                Shaders
              </div>
              <div className="mt-1 text-xl font-medium text-white">
                Включение и выбор
              </div>
            </div>
            <div className="rounded-full border border-white/10 bg-black/10 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-slate-300">
              Visual
            </div>
          </div>

          <div className="space-y-3">
            {shaders.map((shader) => (
              <div
                key={shader.id}
                className={[
                  "rounded-[24px] border p-4 transition-all duration-300",
                  shader.enabled
                    ? "border-cyan-300/25 bg-cyan-300/10"
                    : "border-white/10 bg-black/10",
                ].join(" ")}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-base font-medium text-white">
                      {shader.name}
                    </div>
                    <div className="mt-1 text-sm leading-relaxed text-slate-300">
                      {shader.mood}
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-slate-300">
                        {shader.quality}
                      </span>
                      <span className="rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-slate-300">
                        Shader
                      </span>
                    </div>
                  </div>
                  <Toggle
                    checked={shader.enabled}
                    onClick={() => toggleShader(shader.id)}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>

        <div className="resource-card min-h-0 overflow-auto rounded-[28px] border border-white/10 bg-white/8 p-[clamp(14px,1.6vw,18px)] shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="mb-4 flex items-center justify-between">
            <div>
              <div className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
                Resource Packs
              </div>
              <div className="mt-1 text-xl font-medium text-white">
                Включение и порядок
              </div>
            </div>
            <div className="rounded-full border border-white/10 bg-black/10 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-slate-300">
              Packs
            </div>
          </div>

          <div className="grid grid-cols-1 gap-3 xl:grid-cols-2">
            {packs.map((pack) => (
              <div
                key={pack.id}
                className={[
                  "rounded-[24px] border p-4 transition-all duration-300",
                  pack.enabled
                    ? "border-emerald-300/25 bg-emerald-300/10"
                    : "border-white/10 bg-black/10",
                ].join(" ")}
              >
                <div className="flex items-start justify-between gap-4">
                  <div className="min-w-0">
                    <div className="text-base font-medium text-white">
                      {pack.name}
                    </div>
                    <div className="mt-1 text-sm leading-relaxed text-slate-300">
                      {pack.style}
                    </div>
                    <div className="mt-3 flex flex-wrap items-center gap-2">
                      <span className="rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-slate-300">
                        {pack.resolution}
                      </span>
                      <span className="rounded-full border border-white/10 bg-white/8 px-2.5 py-1 text-[10px] uppercase tracking-[0.18em] text-slate-300">
                        Resource Pack
                      </span>
                    </div>
                  </div>
                  <Toggle
                    checked={pack.enabled}
                    onClick={() => togglePack(pack.id)}
                  />
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

export default Resources;
