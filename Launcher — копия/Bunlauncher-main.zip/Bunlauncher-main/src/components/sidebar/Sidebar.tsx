import { useState, useEffect, useCallback } from "react";
import { GrResources } from "react-icons/gr";
import { IoMdSettings } from "react-icons/io";
import { IoExitOutline, IoPlayOutline } from "react-icons/io5";
import { invoke } from "@tauri-apps/api/core";
import { listen } from "@tauri-apps/api/event";
import { exit } from "@tauri-apps/plugin-process";
import SettingsModal from "../settings/SettingsModal";
import Modal from "../modal/Modal";
import { FaNewspaper, FaShop } from "react-icons/fa6";

type Status = "idle" | "loading" | "launched" | "error";

type Config = {
  username: string;
  memory_mb: number;
  width: number;
  height: number;
};

type LaunchEvent = {
  status: string;
  progress: number;
};

function validateUsername(value: string): string {
  if (!value.trim()) return "";
  if (value.length < 3) return "Минимум 3 символа";
  if (value.length > 16) return "Максимум 16 символов";
  if (!/^[a-zA-Z0-9_]+$/.test(value)) return "Только a–z, A–Z, 0–9 и _";
  return "";
}

function getAvatarLetter(name: string) {
  return name ? name[0].toUpperCase() : "?";
}

function getAvatarColor(name: string) {
  const colors = [
    "bg-green-500/30 text-green-400",
    "bg-blue-500/30 text-blue-400",
    "bg-purple-500/30 text-purple-400",
    "bg-orange-500/30 text-orange-400",
    "bg-pink-500/30 text-pink-400",
  ];
  return colors[name ? name.charCodeAt(0) % colors.length : 0];
}

type NavItemProps = {
  icon: React.ReactNode;
  label: string;
  onClick?: () => void;
  active?: boolean;
};

function NavItem({ icon, label, onClick, active }: NavItemProps) {
  return (
    <button
      onClick={onClick}
      className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-xl transition-all text-sm ${
        active
          ? "bg-white/10 text-white"
          : "text-gray-400 hover:text-white hover:bg-white/5"
      }`}
    >
      <span className="text-lg">{icon}</span>
      <span>{label}</span>
    </button>
  );
}

type ActiveSection = "shop" | "news" | "resources" | null;

const DEFAULT_CONFIG: Config = {
  username: "",
  memory_mb: 5120,
  width: 1280,
  height: 720,
};

const Sidebar = () => {
  const [status, setStatus] = useState<Status>("idle");
  const [errorModal, setErrorModal] = useState("");
  const [nickError, setNickError] = useState("");
  const [progress, setProgress] = useState<LaunchEvent | null>(null);
  const [settingsOpen, setSettingsOpen] = useState(false);
  const [activeSection, setActiveSection] = useState<ActiveSection>(null);
  const [config, setConfig] = useState<Config>(DEFAULT_CONFIG);

  const loadConfig = useCallback(() => {
    invoke<Config>("get_config")
      .then((c) => {
        setConfig(c);
        setNickError(validateUsername(c.username));
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    loadConfig();

    const unlistenProgress = listen<LaunchEvent>("launch-status", (e) => {
      setProgress(e.payload);
      if (e.payload.progress === 100) {
        setStatus("launched");
      }
    });

    const unlistenError = listen<string>("launch-error", (e) => {
      setErrorModal(e.payload);
      setStatus("idle");
      setProgress(null);
    });

    return () => {
      unlistenProgress.then((f) => f());
      unlistenError.then((f) => f());
    };
  }, [loadConfig]);

  const handleNickChange = useCallback(
    (value: string) => {
      const updated = { ...config, username: value };
      setConfig(updated);
      const err = validateUsername(value);
      setNickError(err);
      if (!err && value.trim()) {
        invoke("save_config", { config: updated }).catch(() => {});
      }
    },
    [config],
  );

  const handlePlay = async () => {
    const err = validateUsername(config.username);
    if (err || !config.username.trim()) {
      setErrorModal(err || "Введите никнейм перед запуском");
      return;
    }
    setStatus("loading");
    setProgress(null);
    try {
      await invoke("start_game");
      setStatus("idle");
      setProgress(null);
    } catch (e) {
      setErrorModal(String(e));
      setStatus("idle");
      setProgress(null);
    }
  };

  const handleKeyDown = (e: React.KeyboardEvent<HTMLInputElement>) => {
    if (e.key === "Enter") handlePlay();
  };

  const quit = async () => {
    try {
      await exit(0);
    } catch (e) {
      setErrorModal(String(e));
    }
  };

  const isLoading = status === "loading";
  const isLaunched = status === "launched";
  const nickValid = !nickError && config.username.trim().length >= 3;
  const canPlay =
    !isLoading &&
    !isLaunched &&
    !nickError &&
    config.username.trim().length >= 3;

  return (
    <aside className="w-64 shrink-0 h-screen flex flex-col bg-black/40 backdrop-blur-xl border-r border-white/5">
      <div className="flex items-center h-16 gap-3 px-4 border-b border-white/5 shrink-0">
        <img
          src="/images/bun.png"
          alt="logo"
          className="w-8 h-8 rounded-lg object-cover"
          onError={(e) => (e.currentTarget.style.display = "none")}
        />
        <span className="text-white font-bold text-base tracking-tight select-none">
          NoteBuns
        </span>
      </div>

      <div className="flex-1 flex flex-col gap-2 px-3 py-4 overflow-y-auto scrollbar-thin scrollbar-thumb-white/10">
        <p className="text-xs text-gray-600 uppercase tracking-wider px-3 mb-1 select-none">
          Профиль
        </p>

        <div className="bg-white/5 rounded-xl p-3 border border-white/5">
          <div className="relative mb-2">
            <span
              className={`absolute z-40 left-3 top-1/2 -translate-y-1/2 w-6 h-6 rounded-lg flex items-center justify-center text-xs font-bold select-none ${getAvatarColor(config.username)}`}
            >
              {getAvatarLetter(config.username)}
            </span>
            <input
              value={config.username}
              onChange={(e) => handleNickChange(e.target.value)}
              onKeyDown={handleKeyDown}
              placeholder="Ваш никнейм..."
              maxLength={16}
              disabled={isLoading || isLaunched}
              autoComplete="off"
              spellCheck={false}
              className={`w-full pl-11 pr-3 py-2 rounded-xl bg-black/30 text-white text-sm outline-none border transition-colors placeholder:text-gray-600 disabled:opacity-50 disabled:cursor-not-allowed ${
                nickError
                  ? "border-red-500/50 focus:border-red-500/80"
                  : nickValid
                    ? "border-green-500/30 focus:border-green-500/60"
                    : "border-white/10 focus:border-white/25"
              }`}
            />
          </div>
          <p
            className={`text-xs px-1 transition-colors ${
              nickError
                ? "text-red-400"
                : nickValid
                  ? "text-green-400"
                  : "text-gray-600"
            }`}
          >
            {nickError ||
              (nickValid ? "✓ Готово к игре" : "3–16 символов, a-z, 0-9, _")}
          </p>
        </div>

        <button
          onClick={handlePlay}
          disabled={!canPlay}
          className={`w-full flex items-center justify-center gap-2 py-3.5 rounded-xl text-sm font-semibold transition-all mt-1 select-none ${
            isLaunched
              ? "bg-green-500/20 text-green-400 border border-green-500/30 cursor-default"
              : isLoading
                ? "bg-white/5 text-gray-500 cursor-not-allowed border border-white/5"
                : canPlay
                  ? "bg-green-500/20 hover:bg-green-500/30 active:scale-[0.98] text-green-400 border border-green-500/30 cursor-pointer"
                  : "bg-white/5 text-gray-600 border border-white/5 cursor-not-allowed"
          }`}
        >
          <IoPlayOutline className="text-base shrink-0" />
          <span>
            {isLaunched ? "В игре ✓" : isLoading ? "Загрузка..." : "Играть"}
          </span>
        </button>

        {isLoading && progress && (
          <div className="space-y-1.5 px-1 animate-fade-in">
            <div className="flex justify-between items-center">
              <p className="text-xs text-gray-400 truncate max-w-[80%]">
                {progress.status}
              </p>
              <span className="text-xs text-gray-500 shrink-0">
                {progress.progress}%
              </span>
            </div>
            <div className="h-1 w-full bg-white/10 rounded-full overflow-hidden">
              <div
                className="h-full bg-green-500/70 rounded-full transition-all duration-300 ease-out"
                style={{ width: `${progress.progress}%` }}
              />
            </div>
          </div>
        )}

        <div className="h-px bg-white/5 my-1" />

        <p className="text-xs text-gray-600 uppercase tracking-wider px-3 mb-1 select-none">
          Разделы
        </p>
        <NavItem
          icon={<FaShop />}
          label="Магазин"
          active={activeSection === "shop"}
          onClick={() =>
            setActiveSection((s) => (s === "shop" ? null : "shop"))
          }
        />
        <NavItem
          icon={<FaNewspaper />}
          label="Новости"
          active={activeSection === "news"}
          onClick={() =>
            setActiveSection((s) => (s === "news" ? null : "news"))
          }
        />
        <NavItem
          icon={<GrResources />}
          label="Ресурсы"
          active={activeSection === "resources"}
          onClick={() =>
            setActiveSection((s) => (s === "resources" ? null : "resources"))
          }
        />
      </div>

      <div className="px-3 pb-4 space-y-1 border-t border-white/5 pt-3 shrink-0">
        <NavItem
          icon={<IoMdSettings />}
          label="Настройки"
          onClick={() => setSettingsOpen(true)}
        />
        <button
          onClick={quit}
          className="flex items-center gap-3 w-full px-3 py-2.5 rounded-xl text-red-400/70 hover:text-red-400 hover:bg-red-500/10 active:scale-[0.98] transition-all text-sm select-none"
        >
          <IoExitOutline className="text-lg shrink-0" />
          <span>Выход</span>
        </button>
      </div>

      <SettingsModal
        open={settingsOpen}
        onClose={() => {
          setSettingsOpen(false);
          loadConfig();
        }}
      />
      <Modal
        open={!!errorModal}
        message={errorModal}
        onClose={() => setErrorModal("")}
      />
    </aside>
  );
};

export default Sidebar;
