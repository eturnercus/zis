import gsap from "gsap";
import { useEffect, useMemo, useRef, useState } from "react";
import { invoke } from "@tauri-apps/api/core";

interface NewsItem {
  title: string;
  description: string;
  image: string;
  link: string;
}

function useBlobImage(src: string) {
  const [url, setUrl] = useState("");
  useEffect(() => {
    if (!src) return;
    let obj = "";
    const ctrl = new AbortController();
    fetch(src, { signal: ctrl.signal })
      .then((r) => r.blob())
      .then((b) => {
        obj = URL.createObjectURL(b);
        setUrl(obj);
      })
      .catch(() => setUrl(src));
    return () => {
      ctrl.abort();
      if (obj) URL.revokeObjectURL(obj);
    };
  }, [src]);
  return url;
}

const openLink = async (url: string) => {
  if (!url || url === "#") return;
  try {
    await invoke("open_url", { url });
  } catch {
    window.open(url, "_blank", "noopener,noreferrer");
  }
};

function Slide({ item }: { item: NewsItem }) {
  const imgSrc = useBlobImage(item.image);
  return (
    <div className="flex h-full w-full flex-col overflow-hidden rounded-2xl bg-neutral-900/90 border border-white/10 shadow-xl md:flex-row">
      <div className="relative h-40 w-full shrink-0 overflow-hidden md:h-auto md:w-1/2">
        <img
          src={imgSrc}
          alt={item.title}
          className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-105"
        />
        <div className="pointer-events-none absolute inset-0 bg-linear-to-tr from-black/50 via-transparent to-black/20" />
      </div>
      <div className="flex flex-1 flex-col gap-3 p-4 md:p-6">
        <h3 className="line-clamp-2 text-base font-semibold text-white md:text-lg">
          {item.title}
        </h3>
        <p className="line-clamp-3 text-xs text-neutral-200 md:text-sm">
          {item.description}
        </p>
        <div className="mt-auto pt-2">
          <button
            onClick={() => openLink(item.link)}
            className="inline-flex items-center gap-1 rounded-xl bg-violet-500 px-3 py-1.5 text-xs font-medium text-white shadow-md hover:bg-violet-600 active:scale-95 transition md:text-sm"
          >
            Подробнее
            <span className="text-[10px] md:text-xs">↗</span>
          </button>
        </div>
      </div>
    </div>
  );
}

export default function Slider() {
  const [news, setNews] = useState<NewsItem[]>([]);
  const [index, setIndex] = useState(0);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const slideRef = useRef<HTMLDivElement | null>(null);
  const autoPlayRef = useRef<number | null>(null);
  const [hovered, setHovered] = useState(false);

  useEffect(() => {
    let mounted = true;
    invoke<NewsItem[]>("fetch_news")
      .then((items) => {
        if (!mounted || !items) return;
        const sorted = [...items].reverse();
        setNews(sorted.slice(0, 3));
        setIndex(0);
      })
      .catch(() => setNews([]));
    return () => {
      mounted = false;
    };
  }, []);

  const slides = useMemo(() => news, [news]);

  const goTo = (target: number) => {
    if (!slideRef.current || slides.length === 0) return;
    const from = slideRef.current;
    const tl = gsap.timeline();
    tl.to(from, {
      opacity: 0,
      y: 10,
      duration: 0.2,
      ease: "power2.inOut",
    }).call(() => {
      setIndex(() => {
        const len = slides.length;
        const next = ((target % len) + len) % len;
        return next;
      });
    });
  };

  useEffect(() => {
    if (!slideRef.current) return;
    gsap.fromTo(
      slideRef.current,
      { opacity: 0, y: -10 },
      {
        opacity: 1,
        y: 0,
        duration: 0.3,
        ease: "power2.out",
      },
    );
  }, [index]);

  useEffect(() => {
    if (autoPlayRef.current) {
      window.clearInterval(autoPlayRef.current);
      autoPlayRef.current = null;
    }
    if (slides.length === 0) return;
    const id = window.setInterval(() => {
      if (!hovered) {
        setIndex((prev) => {
          const len = slides.length;
          return (prev + 1) % len;
        });
      }
    }, 8000);
    autoPlayRef.current = id;
    return () => {
      if (autoPlayRef.current) {
        window.clearInterval(autoPlayRef.current);
        autoPlayRef.current = null;
      }
    };
  }, [slides.length, hovered]);

  if (slides.length === 0) {
    return (
      <div className="w-full rounded-2xl border border-white/5 bg-neutral-900/60 p-4 text-sm text-neutral-300">
        Новостей пока нет.
      </div>
    );
  }

  return (
    <div
      ref={containerRef}
      className="relative w-full max-w-4xl mx-auto"
      onMouseEnter={() => setHovered(true)}
      onMouseLeave={() => setHovered(false)}
    >
      <div
        ref={slideRef}
        className="group h-56 w-full md:h-64 lg:h-72 transition-all duration-300"
      >
        <Slide item={slides[index]} />
      </div>
      <div className="pointer-events-none absolute inset-y-0 left-0 right-0 flex items-center justify-between px-2 md:px-4">
        <button
          className="pointer-events-auto flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white shadow-lg hover:bg-black/70 transition md:h-9 md:w-9"
          onClick={() => goTo(index - 1)}
        >
          ‹
        </button>
        <button
          className="pointer-events-auto flex h-8 w-8 items-center justify-center rounded-full bg-black/40 text-white shadow-lg hover:bg-black/70 transition md:h-9 md:w-9"
          onClick={() => goTo(index + 1)}
        >
          ›
        </button>
      </div>
      <div className="mt-3 flex justify-center gap-2">
        {slides.map((_, i) => (
          <button
            key={i}
            onClick={() => goTo(i)}
            className={`h-1.5 rounded-full transition-all ${
              i === index
                ? "w-6 bg-violet-400"
                : "w-2.5 bg-neutral-500 hover:bg-neutral-300"
            }`}
          />
        ))}
      </div>
    </div>
  );
}
