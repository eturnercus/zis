import { useLayoutEffect, useRef, useState } from "react";
import gsap from "gsap";
import { invoke } from "@tauri-apps/api/core";
import {
  IoOpenOutline,
  IoRefreshOutline,
  IoLocateOutline,
} from "react-icons/io5";

async function openExternal(url: string) {
  if (!url) return;
  try {
    await invoke("open_url", { url });
  } catch {
    window.open(url, "_blank", "noopener,noreferrer");
  }
}

const BLUEMAP_URL = import.meta.env.VITE_BLUEMAP_URL ?? "https://map.null/";

function Map() {
  const [frameKey, setFrameKey] = useState(0);
  const rootRef = useRef<HTMLDivElement>(null);

  useLayoutEffect(() => {
    if (!rootRef.current) return;
    gsap.fromTo(
      rootRef.current.querySelectorAll(".map-card"),
      { opacity: 0, y: 18, scale: 0.99 },
      {
        opacity: 1,
        y: 0,
        scale: 1,
        duration: 0.55,
        stagger: 0.08,
        ease: "power3.out",
      },
    );
  }, []);

  return (
    <section
      ref={rootRef}
      className="grid h-full min-h-0 grid-cols-1 gap-[clamp(12px,1.5vw,18px)] xl:grid-rows-[auto_1fr]"
    >
      <div className="grid grid-cols-1 gap-[clamp(12px,1.5vw,18px)] lg:grid-cols-[1fr_auto]">
        <div className="map-card rounded-[28px] border border-white/10 bg-white/8 px-[clamp(16px,1.8vw,22px)] py-[clamp(14px,1.6vw,18px)] shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <div className="text-[11px] uppercase tracking-[0.24em] text-slate-400">
            BlueMap
          </div>
          <div className="mt-1 text-[clamp(20px,2vw,28px)] font-medium text-white">
            Интерактивная карта мира
          </div>
          <div className="mt-3 max-w-[78ch] text-sm leading-relaxed text-slate-300">
            Встроенный просмотр территории, построек и маршрутов сервера через
            web-рендер.
          </div>
        </div>

        <div className="map-card flex flex-wrap items-center gap-3 rounded-[28px] border border-white/10 bg-white/8 p-[clamp(14px,1.6vw,18px)] shadow-[0_18px_70px_rgba(0,0,0,0.28)] backdrop-blur-2xl">
          <button
            type="button"
            onClick={() => setFrameKey((prev) => prev + 1)}
            className="inline-flex items-center gap-2 rounded-2xl border border-white/10 bg-black/10 px-4 py-3 text-sm font-medium text-white transition hover:bg-white/10"
          >
            <IoRefreshOutline size={18} />
            Обновить
          </button>

          <button
            type="button"
            onClick={() => openExternal(BLUEMAP_URL)}
            className="inline-flex items-center gap-2 rounded-2xl border border-cyan-300/25 bg-cyan-300/14 px-4 py-3 text-sm font-medium text-white transition hover:bg-cyan-300/20"
          >
            <IoOpenOutline size={18} />
            Открыть
          </button>
        </div>
      </div>

      <div className="map-card min-h-0 overflow-hidden rounded-[30px] border border-white/10 bg-[#09131d] shadow-[0_20px_90px_rgba(0,0,0,0.35)]">
        <div className="flex items-center justify-between border-b border-white/8 px-[clamp(14px,1.6vw,18px)] py-3">
          <div className="flex items-center gap-3">
            <div className="flex h-10 w-10 items-center justify-center rounded-2xl border border-white/10 bg-white/8 text-cyan-200">
              <IoLocateOutline size={18} />
            </div>
            <div>
              <div className="text-sm font-medium text-white">
                Map Live View
              </div>
              <div className="text-xs text-slate-400">{BLUEMAP_URL}</div>
            </div>
          </div>
          <div className="rounded-full border border-white/10 bg-black/10 px-3 py-1 text-[11px] uppercase tracking-[0.18em] text-slate-300">
            Embedded
          </div>
        </div>

        <div className="h-[calc(100%-65px)] min-h-[320px] bg-[#081019] p-[clamp(8px,1vw,12px)]">
          <iframe
            key={frameKey}
            src={BLUEMAP_URL}
            className="h-full w-full rounded-[24px] border border-white/8 bg-[#0a1320]"
            allowFullScreen
            title="BlueMap"
          />
        </div>
      </div>
    </section>
  );
}

export default Map;
