import { useEffect } from "react";
import { IoClose, IoWarningOutline } from "react-icons/io5";
import { Portal } from "../Portal";

type ModalProps = {
  open: boolean;
  title?: string;
  message: string;
  onClose: () => void;
};

export default function Modal({
  open,
  title = "Ошибка",
  message,
  onClose,
}: ModalProps) {
  useEffect(() => {
    if (!open) return;
    const handler = (e: KeyboardEvent) => {
      if (e.key === "Escape") onClose();
    };
    window.addEventListener("keydown", handler);
    return () => window.removeEventListener("keydown", handler);
  }, [open, onClose]);

  if (!open) return null;

  return (
    <Portal>
      <div
        className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <div className="relative w-[90%] max-w-md rounded-2xl bg-neutral-900/95 p-6 shadow-2xl border border-red-500/40 animate-[modal-in_220ms_ease-out]">
          <div className="flex items-center gap-3 mb-4">
            <div className="flex h-10 w-10 items-center justify-center rounded-full bg-red-500/15 text-red-400">
              <IoWarningOutline className="h-6 w-6" />
            </div>
            <h2 className="text-lg font-semibold text-red-300">{title}</h2>
            <button
              onClick={onClose}
              className="ml-auto inline-flex h-8 w-8 items-center justify-center rounded-full bg-white/5 text-neutral-300 hover:bg-white/10 transition-colors"
            >
              <IoClose className="h-5 w-5" />
            </button>
          </div>
          <div className="max-h-52 overflow-y-auto pr-1 text-sm text-neutral-100 whitespace-pre-wrap">
            {message}
          </div>
          <div className="mt-5 flex justify-end">
            <button
              onClick={onClose}
              className="inline-flex items-center justify-center rounded-xl bg-red-500 px-4 py-2 text-sm font-medium text-white hover:bg-red-600 active:scale-[0.97] transition-transform"
            >
              Понятно
            </button>
          </div>
        </div>
      </div>
      <style>{`
        @keyframes modal-in {
          from { opacity: 0; transform: translateY(12px) scale(0.97); }
          to { opacity: 1; transform: translateY(0) scale(1); }
        }
      `}</style>
    </Portal>
  );
}
