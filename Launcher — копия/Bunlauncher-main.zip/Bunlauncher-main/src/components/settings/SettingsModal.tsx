import { useState, useEffect } from "react";
import { invoke } from "@tauri-apps/api/core";
import { open as openDialog } from "@tauri-apps/plugin-dialog";
import { homeDir, join } from "@tauri-apps/api/path";
import { X, Monitor, Cpu, FolderOpen } from "lucide-react";
import { Portal } from "../Portal";

export interface Config {
  username: string;
  memory_mb: number;
  width: number;
  height: number;
  game_dir: string | null;
}

interface Props {
  open: boolean;
  onClose: () => void;
}

const PRESETS = [
  { label: "1280×720", w: 1280, h: 720 },
  { label: "1366×768", w: 1366, h: 768 },
  { label: "1600×900", w: 1600, h: 900 },
  { label: "1920×1080", w: 1920, h: 1080 },
];

const RAM_MARKS = [5120, 6144, 8192, 10240, 12288];

const DEFAULT_CONFIG: Config = {
  username: "",
  memory_mb: 6144,
  width: 1280,
  height: 720,
  game_dir: null,
};

function validateConfig(c: Partial<Config>): Config {
  return {
    username:
      typeof c.username === "string"
        ? c.username.slice(0, 16)
        : DEFAULT_CONFIG.username,
    memory_mb: Number.isFinite(c.memory_mb)
      ? Math.min(Math.max(Number(c.memory_mb), 5120), 12288)
      : DEFAULT_CONFIG.memory_mb,
    width: Number.isFinite(c.width)
      ? Math.min(Math.max(Number(c.width), 800), 1920)
      : DEFAULT_CONFIG.width,
    height: Number.isFinite(c.height)
      ? Math.min(Math.max(Number(c.height), 600), 1080)
      : DEFAULT_CONFIG.height,
    game_dir: c.game_dir || null,
  };
}

export default function SettingsModal({ open, onClose }: Props) {
  const [cfg, setCfg] = useState<Config>(DEFAULT_CONFIG);
  const [saved, setSaved] = useState(false);
  const [defaultPath, setDefaultPath] = useState<string>("Загрузка пути...");

  useEffect(() => {
    if (open) {
      invoke<Config>("get_config")
        .then((c) => setCfg(validateConfig(c)))
        .catch(() => setCfg(DEFAULT_CONFIG));

      // Получаем реальный дефолтный путь
      homeDir()
        .then((home) => join(home, ".NoteBuns"))
        .then((path) => setDefaultPath(path))
        .catch(() => setDefaultPath("~/.NoteBuns"));
    }
  }, [open]);

  function setField<K extends keyof Config>(key: K, value: Config[K]) {
    setCfg((prev) => ({ ...prev, [key]: value }));
  }

  async function handleSelectDirectory() {
    try {
      const selectedPath = await openDialog({
        directory: true,
        multiple: false,
        title: "Выберите папку для игры",
        defaultPath: cfg.game_dir || defaultPath, // Открываем диалог в текущей папке
      });

      if (selectedPath !== null && typeof selectedPath === "string") {
        setField("game_dir", selectedPath);
      }
    } catch (e) {
      console.error(e);
    }
  }

  async function handleSave() {
    try {
      const validCfg = validateConfig(cfg);
      setCfg(validCfg);

      await invoke("save_config", { config: validCfg });
      setSaved(true);
      setTimeout(() => {
        setSaved(false);
        onClose();
      }, 800);
    } catch (e) {
      console.error(e);
    }
  }

  if (!open) return null;

  const ramPercent =
    ((RAM_MARKS.indexOf(cfg.memory_mb) === -1
      ? 1
      : RAM_MARKS.indexOf(cfg.memory_mb)) /
      (RAM_MARKS.length - 1)) *
    100;

  return (
    <Portal>
      <div
        className="fixed z-999 inset-0 w-screen flex items-center justify-center bg-black/60 backdrop-blur-sm"
        onClick={(e) => e.target === e.currentTarget && onClose()}
      >
        <div className="relative w-120 rounded-2xl bg-[#111111] border border-white/10 shadow-2xl overflow-hidden">
          <div className="flex items-center justify-between px-6 py-4 border-b border-white/10">
            <span className="text-white font-semibold text-base tracking-wide">
              Настройки
            </span>
            <button
              onClick={onClose}
              className="p-1 rounded-lg text-gray-400 hover:text-white hover:bg-white/10 transition-colors"
            >
              <X size={18} />
            </button>
          </div>

          <div className="px-6 py-5 flex flex-col gap-6">
            <section>
              <div className="flex items-center gap-2 mb-3 text-gray-400 text-xs uppercase tracking-widest">
                <FolderOpen size={13} />
                <span>Папка игры</span>
              </div>
              <div className="flex gap-2">
                <div
                  className="flex-1 bg-[#1a1a1a] rounded-xl px-4 py-2.5 border border-white/10 text-gray-400 text-sm truncate"
                  title={cfg.game_dir || defaultPath} // Показывает полный путь при наведении
                >
                  {cfg.game_dir || defaultPath}
                </div>
                <button
                  onClick={handleSelectDirectory}
                  className="px-4 py-2.5 rounded-xl bg-white/5 border border-white/10 text-white text-sm hover:bg-white/10 transition-colors whitespace-nowrap"
                >
                  Изменить
                </button>
              </div>
            </section>

            <section>
              <div className="flex items-center gap-2 mb-3 text-gray-400 text-xs uppercase tracking-widest">
                <Cpu size={13} />
                <span>Оперативная память</span>
              </div>

              <div className="flex items-center justify-between mb-2">
                <span className="text-white text-sm font-medium">
                  {cfg.memory_mb >= 1024
                    ? `${cfg.memory_mb / 1024} GB`
                    : `${cfg.memory_mb} MB`}
                </span>
                <span className="text-gray-500 text-xs">
                  Рекомендуется 6 GB
                </span>
              </div>

              <input
                type="range"
                min={0}
                max={RAM_MARKS.length - 1}
                step={1}
                value={
                  RAM_MARKS.indexOf(cfg.memory_mb) === -1
                    ? 1
                    : RAM_MARKS.indexOf(cfg.memory_mb)
                }
                onChange={(e) =>
                  setField("memory_mb", RAM_MARKS[Number(e.target.value)])
                }
                className="w-full h-1.5 appearance-none rounded-full outline-none cursor-pointer
                [&::-webkit-slider-thumb]:appearance-none
                [&::-webkit-slider-thumb]:w-4
                [&::-webkit-slider-thumb]:h-4
                [&::-webkit-slider-thumb]:rounded-full
                [&::-webkit-slider-thumb]:bg-[#4ade80]
                [&::-webkit-slider-thumb]:cursor-pointer
                [&::-webkit-slider-thumb]:border-2
                [&::-webkit-slider-thumb]:border-black"
                style={{
                  background: `linear-gradient(to right, #4ade80 ${ramPercent}%, #2a2a2a ${ramPercent}%)`,
                }}
              />

              <div className="flex justify-between mt-2">
                {RAM_MARKS.map((v) => (
                  <span
                    key={v}
                    onClick={() => setField("memory_mb", v)}
                    className={`text-[10px] cursor-pointer transition-colors ${
                      cfg.memory_mb === v
                        ? "text-[#4ade80]"
                        : "text-gray-600 hover:text-gray-400"
                    }`}
                  >
                    {v >= 1024 ? `${v / 1024}G` : `${v}`}
                  </span>
                ))}
              </div>
            </section>

            <section>
              <div className="flex items-center gap-2 mb-3 text-gray-400 text-xs uppercase tracking-widest">
                <Monitor size={13} />
                <span>Разрешение окна при запуске</span>
              </div>

              <div className="flex gap-2 mb-3 flex-wrap">
                {PRESETS.map((p) => (
                  <button
                    key={p.label}
                    onClick={() => {
                      setField("width", p.w);
                      setField("height", p.h);
                    }}
                    className={`px-3 py-1 rounded-lg text-xs transition-colors border ${
                      cfg.width === p.w && cfg.height === p.h
                        ? "bg-[#4ade80]/10 border-[#4ade80]/50 text-[#4ade80]"
                        : "border-white/10 text-gray-400 hover:border-white/20 hover:text-white"
                    }`}
                  >
                    {p.label}
                  </button>
                ))}
              </div>

              <div className="flex items-center gap-3">
                <div className="flex-1 relative">
                  <style>
                    {`
                      input[type="number"]::-webkit-inner-spin-button,
                      input[type="number"]::-webkit-outer-spin-button {
                        -webkit-appearance: none;
                        margin: 0;
                      }
                      input[type="number"] {
                        -moz-appearance: textfield;
                      }
                    `}
                  </style>
                  <input
                    type="number"
                    value={cfg.width}
                    onChange={(e) => setField("width", Number(e.target.value))}
                    className="w-full bg-[#1a1a1a] rounded-xl px-4 py-2.5 text-white text-sm outline-none border border-white/10 focus:border-white/30 transition-colors"
                  />
                  <span className="absolute z-999 right-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs pointer-events-none">
                    W
                  </span>
                </div>
                <span className="text-gray-600 text-sm">×</span>
                <div className="flex-1 relative">
                  <input
                    type="number"
                    value={cfg.height}
                    onChange={(e) => setField("height", Number(e.target.value))}
                    className="w-full bg-[#1a1a1a] rounded-xl px-4 py-2.5 text-white text-sm outline-none border border-white/10 focus:border-white/30 transition-colors"
                  />
                  <span className="absolute z-999 right-3 top-1/2 -translate-y-1/2 text-gray-500 text-xs pointer-events-none">
                    H
                  </span>
                </div>
              </div>
            </section>
          </div>

          <div className="flex gap-3 px-6 py-4 border-t border-white/10">
            <button
              onClick={onClose}
              className="flex-1 py-2.5 rounded-xl text-sm text-gray-400 border border-white/10 hover:border-white/20 hover:text-white transition-colors"
            >
              Отмена
            </button>
            <button
              onClick={handleSave}
              disabled={saved}
              className={`flex-1 py-2.5 rounded-xl text-sm font-medium transition-all
              ${
                saved
                  ? "bg-[#4ade80]/20 text-[#4ade80] border border-[#4ade80]/30"
                  : "bg-[#4ade80] text-black hover:bg-[#22c55e] disabled:opacity-40 disabled:cursor-not-allowed"
              }`}
            >
              {saved ? "Сохранено ✓" : "Сохранить"}
            </button>
          </div>
        </div>
      </div>
    </Portal>
  );
}
