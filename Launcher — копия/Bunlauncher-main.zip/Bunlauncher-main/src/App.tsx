import "./App.css";
import Header from "./components/header/Header";
import Sidebar from "./components/sidebar/Sidebar";
import Slider from "./components/slider/Slider";

function App() {
  return (
    <div className="flex h-screen w-screen bg-[url('/images/note.jpg')] bg-cover overflow-hidden bg-[#0f1117]">
      <Sidebar />
      <div className="flex flex-col flex-1 min-w-0 overflow-hidden">
        <Header />
        <main className="flex-1 overflow-y-auto px-6 py-4">
          <Slider />
        </main>
      </div>
    </div>
  );
}

export default App;
